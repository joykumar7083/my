# test_server.py
from flask import Flask

app = Flask(__name__)

@app.route('/')
def home():
    return '''
    <!DOCTYPE html>
    <html>
    <head>
        <title>Test Server 5008</title>
        <style>
            body { background: #0a0c14; color: #e5e7eb; font-family: Arial; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
            .box { background: #1a1d28; border: 1px solid #6366f1; border-radius: 16px; padding: 40px; text-align: center; max-width: 500px; }
            .badge { background: #10b981; color: #fff; padding: 4px 16px; border-radius: 20px; font-size: 12px; display: inline-block; }
            h1 { color: #818cf8; font-size: 28px; }
            .info { color: #9ca3af; font-size: 14px; margin: 16px 0; }
            .port { background: #0a0c14; padding: 8px 20px; border-radius: 8px; font-size: 18px; color: #34d399; }
        </style>
    </head>
    <body>
        <div class="box">
            <span class="badge">ACTIVE</span>
            <h1>Test Server</h1>
            <p class="info">This is a test server running on port 5008</p>
            <div class="port">Port: 5008</div>
            <p style="color:#6b7280;font-size:12px;margin-top:16px;">Server ID: C0D7520C</p>
        </div>
    </body>
    </html>
    '''

@app.route('/health')
def health():
    return {'status': 'ok', 'port': 5008, 'server': 'C0D7520C'}

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5010, debug=False)