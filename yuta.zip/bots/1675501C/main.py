# YUTA CLOUD HOSTING - Secure Default Bot
import time
import os
import sys

PORT = int(os.environ.get('PORT', 5000))

def main():
    print("=" * 50)
    print("🚀 YUTA CLOUD HOSTING - Secure Bot")
    print(f"📍 Port: {PORT}")
    print("=" * 50)
    
    counter = 0
    while True:
        counter += 1
        print(f"[{time.strftime('%H:%M:%S')}] Heartbeat #{counter} | Port: {PORT} | Active")
        time.sleep(10)

if __name__ == "__main__":
    main()
