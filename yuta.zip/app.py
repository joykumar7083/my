from flask import Flask, render_template, request, redirect, url_for, session, jsonify, make_response
import json
import os
import subprocess
import random
import string
import uuid
from datetime import datetime, timedelta
import sys
import shutil
import threading
import time
import zipfile
import psutil
import hashlib
import hmac
import secrets
import re
from functools import wraps
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
import logging
from logging.handlers import RotatingFileHandler

# ============================================
# SECURE LOGGING SYSTEM
# ============================================
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger('YUTA_CLOUD')
handler = RotatingFileHandler('yuta_cloud.log', maxBytes=10000000, backupCount=5)
handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
logger.addHandler(handler)

# ============================================
# SECURE CONFIGURATION
# ============================================
app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', secrets.token_hex(32))
app.config['MAX_CONTENT_LENGTH'] = 50 * 1024 * 1024

# Session Configuration - Production ready
app.config['SESSION_COOKIE_SECURE'] = True
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'
app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(days=30)
app.config['SESSION_PERMANENT'] = True
app.config['SESSION_REFRESH_EACH_REQUEST'] = True
app.permanent_session_lifetime = timedelta(days=30)

# ============================================
# SECURITY MIDDLEWARE (FIXED FOR UI)
# ============================================
@app.after_request
def security_headers(response):
    """Add security headers to all responses - Fixed for UI"""
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'DENY'
    response.headers['X-XSS-Protection'] = '1; mode=block'
    
    if not app.debug:
        response.headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains'
    
    response.headers['Content-Security-Policy'] = (
        "default-src 'self'; "
        "script-src 'self' 'unsafe-inline' 'unsafe-eval' https://cdn.tailwindcss.com https://cdn.jsdelivr.net https://cdnjs.cloudflare.com https://unpkg.com; "
        "style-src 'self' 'unsafe-inline' https://cdn.tailwindcss.com https://cdnjs.cloudflare.com https://fonts.googleapis.com; "
        "font-src 'self' https://cdnjs.cloudflare.com https://fonts.gstatic.com data:; "
        "img-src 'self' data: https:; "
        "connect-src 'self' https:;"
    )
    
    response.headers['Referrer-Policy'] = 'strict-origin-when-cross-origin'
    return response

# ============================================
# RATE LIMITER
# ============================================
limiter = Limiter(
    app=app,
    key_func=get_remote_address,
    default_limits=["200 per minute", "1000 per hour"],
    storage_uri="memory://"
)

# ============================================
# SECURITY CONSTANTS
# ============================================
USERS_FILE = 'users.json'
BOTS_DIR = 'bots'
CPU_HISTORY = {}
CRASH_COUNT = {}
NET_STATS = {}
PORT_ALLOCATIONS = {}
BLACKLISTED_TOKENS = set()
FAILED_LOGIN_ATTEMPTS = {}
RATE_LIMIT_DATA = {}
INVALID_REQUESTS = {}

# YUTA CLOUD HOSTING Files
SETTINGS_FILE = 'yuta_settings.json'
PACKAGES_FILE = 'yuta_packages.json'
INVOICES_FILE = 'yuta_invoices.json'
FREE_TRIALS_FILE = 'yuta_free_trials.json'
RESOURCES_FILE = 'yuta_resources.json'
MAINTENANCE_FILE = 'yuta_maintenance.json'
PORTS_FILE = 'port_allocations.json'
AUDIT_LOG_FILE = 'audit.log'
NODES_FILE = 'nodes.json'

os.makedirs(BOTS_DIR, exist_ok=True)

# ============================================
# AUDIT LOGGING
# ============================================
def audit_log(action, username, details="", ip=None):
    try:
        with open(AUDIT_LOG_FILE, 'a', encoding='utf-8') as f:
            log_entry = {
                'timestamp': str(datetime.now()),
                'action': action,
                'username': username,
                'ip': ip or request.remote_addr,
                'details': details,
                'user_agent': request.headers.get('User-Agent', 'Unknown')
            }
            f.write(json.dumps(log_entry) + '\n')
    except:
        pass

# ============================================
# SECURITY DECORATORS
# ============================================
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user' not in session:
            return jsonify({'error': 'Authentication required'}), 401
        return f(*args, **kwargs)
    return decorated_function

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user' not in session or session.get('role') != 'admin':
            return jsonify({'error': 'Admin privileges required'}), 403
        return f(*args, **kwargs)
    return decorated_function

def rate_limit(limit_per_minute=60):
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            client_ip = request.remote_addr
            current_time = time.time()
            
            if client_ip not in RATE_LIMIT_DATA:
                RATE_LIMIT_DATA[client_ip] = []
            
            RATE_LIMIT_DATA[client_ip] = [t for t in RATE_LIMIT_DATA[client_ip] 
                                         if current_time - t < 60]
            
            if len(RATE_LIMIT_DATA[client_ip]) >= limit_per_minute:
                return jsonify({'error': 'Rate limit exceeded'}), 429
            
            RATE_LIMIT_DATA[client_ip].append(current_time)
            return f(*args, **kwargs)
        return decorated_function
    return decorator

def check_expiry(server_id):
    server, username = get_server_by_id(server_id)
    if not server:
        return False, "deleted"
    
    expiry = server.get('expiry', '')
    if expiry:
        try:
            exp_date = datetime.strptime(expiry, '%Y-%m-%d %H:%M:%S.%f')
            if datetime.now() > exp_date:
                return False, "expired"
        except:
            pass
    
    return True, server

def require_valid_server(f):
    @wraps(f)
    def wrapper(server_id, *args, **kwargs):
        valid, result = check_expiry(server_id)
        if not valid:
            return jsonify({
                'status': 'error', 
                'message': f'Server {result}!'
            }), 410 if result == 'expired' else 404
        return f(server_id, *args, **kwargs)
    wrapper.__name__ = f.__name__
    return wrapper

# ============================================
# PASSWORD FUNCTIONS (NO HASHING - PLAIN TEXT)
# ============================================
def hash_password(password):
    """NO HASHING - Returns plain text (INSECURE - Development Only)"""
    return password

def verify_password(password, stored):
    """Verify plain text password"""
    return password == stored

def generate_secure_token():
    return secrets.token_urlsafe(32)

def sanitize_input(text):
    if not text:
        return text
    text = re.sub(r'[<>]', '', text)
    text = re.sub(r'[;]', '', text)
    text = re.sub(r'[&]', '&amp;', text)
    text = re.sub(r'["]', '&quot;', text)
    text = re.sub(r"[']", '&#x27;', text)
    text = re.sub(r'[/]', '&#x2F;', text)
    return text

def validate_username(username):
    if not username or len(username) < 3:
        return False, "Username must be at least 3 characters"
    if not re.match(r'^[a-zA-Z0-9_]+$', username):
        return False, "Username can only contain letters, numbers and underscores"
    return True, ""

def validate_password(password):
    if not password or len(password) < 8:
        return False, "Password must be at least 8 characters"
    if not re.search(r'[A-Z]', password):
        return False, "Password must contain at least one uppercase letter"
    if not re.search(r'[a-z]', password):
        return False, "Password must contain at least one lowercase letter"
    if not re.search(r'[0-9]', password):
        return False, "Password must contain at least one number"
    return True, ""

def validate_email(email):
    if not email:
        return True, ""
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    if re.match(pattern, email):
        return True, ""
    return False, "Invalid email format"

# ============================================
# CSRF PROTECTION
# ============================================
def generate_csrf_token():
    if 'csrf_token' not in session:
        session['csrf_token'] = secrets.token_urlsafe(32)
    return session['csrf_token']

def validate_csrf_token(token):
    return token == session.get('csrf_token')

# ============================================
# PORT MANAGEMENT SYSTEM
# ============================================
def load_port_allocations():
    global PORT_ALLOCATIONS
    if not os.path.exists(PORTS_FILE):
        save_port_allocations({})
        return {}
    try:
        with open(PORTS_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
            PORT_ALLOCATIONS = {int(k): v for k, v in data.items()}
            return PORT_ALLOCATIONS
    except:
        return {}

def save_port_allocations(data=None):
    if data is None:
        data = PORT_ALLOCATIONS
    with open(PORTS_FILE, 'w', encoding='utf-8') as f:
        json.dump({str(k): v for k, v in data.items()}, f, indent=4, ensure_ascii=False)

def get_next_available_port(start_port=5001, end_port=6000):
    load_port_allocations()
    used_ports = set(PORT_ALLOCATIONS.keys())
    for conn in psutil.net_connections():
        if conn.laddr.port in range(start_port, end_port + 1):
            used_ports.add(conn.laddr.port)
    for port in range(start_port, end_port + 1):
        if port not in used_ports:
            return port
    return None

def assign_port(server_id, requested_port=None):
    remove_port_assignment(server_id)
    if requested_port:
        if requested_port in PORT_ALLOCATIONS:
            return None, f"Port {requested_port} is already in use!"
        for conn in psutil.net_connections():
            if conn.laddr.port == requested_port:
                return None, f"Port {requested_port} is already in use by system!"
        port = requested_port
    else:
        port = get_next_available_port()
        if port is None:
            return None, "No ports available! Contact admin."
    PORT_ALLOCATIONS[port] = {
        'server_id': server_id,
        'assigned_at': str(datetime.now()),
        'status': 'assigned'
    }
    save_port_allocations()
    return port, None

def remove_port_assignment(server_id):
    global PORT_ALLOCATIONS
    port_to_remove = None
    for port, info in PORT_ALLOCATIONS.items():
        if info.get('server_id') == server_id:
            port_to_remove = port
            break
    if port_to_remove:
        del PORT_ALLOCATIONS[port_to_remove]
        save_port_allocations()
        return port_to_remove
    return None

def get_server_port(server_id):
    for port, info in PORT_ALLOCATIONS.items():
        if info.get('server_id') == server_id:
            return port
    return None

def get_all_used_ports():
    load_port_allocations()
    used_ports = []
    for port, info in PORT_ALLOCATIONS.items():
        used_ports.append({
            'port': port,
            'server_id': info.get('server_id', ''),
            'assigned_at': info.get('assigned_at', ''),
            'status': info.get('status', 'assigned')
        })
    return used_ports

load_port_allocations()

# ============================================
# NODE MANAGEMENT SYSTEM
# ============================================
def load_nodes():
    if not os.path.exists(NODES_FILE):
        default = {
            'nodes': {},
            'server_node_mapping': {}
        }
        save_nodes(default)
        return default
    with open(NODES_FILE, 'r', encoding='utf-8') as f:
        return json.load(f)

def save_nodes(data):
    with open(NODES_FILE, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=4, ensure_ascii=False)

def get_node_for_server(server_id):
    nodes_data = load_nodes()
    mapping = nodes_data.get('server_node_mapping', {})
    return mapping.get(server_id)

def assign_server_to_node(server_id, node_id=None):
    nodes_data = load_nodes()
    nodes = nodes_data.get('nodes', {})
    mapping = nodes_data.get('server_node_mapping', {})
    
    if server_id in mapping:
        return mapping[server_id]
    
    if node_id and node_id in nodes:
        mapping[server_id] = node_id
        nodes[node_id]['current_servers'] = nodes[node_id].get('current_servers', 0) + 1
        nodes_data['server_node_mapping'] = mapping
        save_nodes(nodes_data)
        return node_id
    
    least_loaded = None
    min_servers = float('inf')
    
    for node_id, node in nodes.items():
        if node.get('status') == 'online':
            current = node.get('current_servers', 0)
            max_servers = node.get('max_servers', 50)
            if current < max_servers and current < min_servers:
                min_servers = current
                least_loaded = node_id
    
    if least_loaded:
        mapping[server_id] = least_loaded
        nodes[least_loaded]['current_servers'] = nodes[least_loaded].get('current_servers', 0) + 1
        nodes_data['server_node_mapping'] = mapping
        save_nodes(nodes_data)
        return least_loaded
    
    return None

# ============================================
# MAINTENANCE SYSTEM
# ============================================
def load_maintenance():
    if not os.path.exists(MAINTENANCE_FILE):
        default = {
            'enabled': False,
            'reason': 'We are performing scheduled maintenance. Please check back later.',
            'started_at': str(datetime.now()),
            'estimated_end': str(datetime.now() + timedelta(hours=2)),
            'remaining_minutes': 120,
            'allowed_ips': ['127.0.0.1'],
            'allowed_admins': True,
            'title': 'Under Maintenance',
            'contact': 'https://t.me/yuta_005'
        }
        save_maintenance(default)
        return default
    with open(MAINTENANCE_FILE, 'r', encoding='utf-8') as f:
        return json.load(f)

def save_maintenance(data):
    with open(MAINTENANCE_FILE, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=4, ensure_ascii=False)

# ============================================
# MAINTENANCE CHECK
# ============================================
@app.before_request
def check_maintenance():
    allowed_prefixes = [
        '/admin', '/login', '/logout', '/static', '/api/',
        '/signin', '/signup', '/user/login', '/user/register',
        '/favicon.ico', '/health', '/api/health'
    ]
    
    for prefix in allowed_prefixes:
        if request.path.startswith(prefix):
            return None
    
    maintenance = load_maintenance()
    
    if maintenance.get('enabled', False):
        client_ip = request.remote_addr
        allowed_ips = maintenance.get('allowed_ips', [])
        if client_ip in allowed_ips:
            return None
        
        if 'user' in session and session.get('role') == 'admin':
            return None
        
        logger.warning(f"Maintenance block: {request.path} from {client_ip}")
        return render_template('maintenance.html', maintenance=maintenance), 503

@app.before_request
def refresh_session():
    if 'user' in session:
        session.permanent = True
        session.modified = True

# ============================================
# CUSTOM RESOURCES MANAGEMENT
# ============================================
def load_resources():
    if not os.path.exists(RESOURCES_FILE):
        default = {
            'ram': [
                {'id': 'ram_512mb', 'name': '512 MB RAM', 'size': '512MB', 'price': 30, 'active': True},
                {'id': 'ram_1gb', 'name': '1 GB RAM', 'size': '1GB', 'price': 50, 'active': True},
                {'id': 'ram_2gb', 'name': '2 GB RAM', 'size': '2GB', 'price': 100, 'active': True},
                {'id': 'ram_3gb', 'name': '3 GB RAM', 'size': '3GB', 'price': 150, 'active': True}
            ],
            'cpu': [
                {'id': 'cpu_50', 'name': '50% CPU', 'limit': 50, 'price': 20, 'active': True},
                {'id': 'cpu_75', 'name': '75% CPU', 'limit': 75, 'price': 50, 'active': True},
                {'id': 'cpu_90', 'name': '90% CPU', 'limit': 90, 'price': 80, 'active': True},
                {'id': 'cpu_100', 'name': '100% CPU', 'limit': 100, 'price': 120, 'active': True}
            ],
            'disk': [
                {'id': 'disk_1gb', 'name': '1 GB Disk', 'size': '1GB', 'price': 20, 'active': True},
                {'id': 'disk_5gb', 'name': '5 GB Disk', 'size': '5GB', 'price': 40, 'active': True},
                {'id': 'disk_10gb', 'name': '10 GB Disk', 'size': '10GB', 'price': 60, 'active': True},
                {'id': 'disk_15gb', 'name': '15 GB Disk', 'size': '15GB', 'price': 80, 'active': True}
            ]
        }
        save_resources(default)
        return default
    with open(RESOURCES_FILE, 'r', encoding='utf-8') as f:
        return json.load(f)

def save_resources(data):
    with open(RESOURCES_FILE, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=4, ensure_ascii=False)

# ============================================
# ADMIN MAINTENANCE API
# ============================================
@app.route('/admin/maintenance')
@login_required
@admin_required
def admin_maintenance_page():
    maintenance = load_maintenance()
    return render_template('admin_maintenance.html', maintenance=maintenance)

@app.route('/admin/api/maintenance/get')
@login_required
@admin_required
def admin_get_maintenance():
    maintenance = load_maintenance()
    return jsonify({'success': True, 'maintenance': maintenance})

@app.route('/admin/api/maintenance/save', methods=['POST'])
@login_required
@admin_required
def admin_save_maintenance():
    data = request.get_json()
    maintenance = load_maintenance()
    
    if 'enabled' in data:
        maintenance['enabled'] = bool(data['enabled'])
        if data['enabled']:
            maintenance['started_at'] = str(datetime.now())
    
    if 'reason' in data:
        maintenance['reason'] = sanitize_input(data['reason'])
    
    if 'title' in data:
        maintenance['title'] = sanitize_input(data['title'])
    
    if 'contact' in data:
        maintenance['contact'] = sanitize_input(data['contact'])
    
    if 'allowed_admins' in data:
        maintenance['allowed_admins'] = bool(data['allowed_admins'])
    
    if 'allowed_ips' in data:
        maintenance['allowed_ips'] = data['allowed_ips']
    
    if 'remaining_minutes' in data:
        maintenance['remaining_minutes'] = int(data['remaining_minutes'])
        maintenance['estimated_end'] = str(datetime.now() + timedelta(minutes=int(data['remaining_minutes'])))
    
    save_maintenance(maintenance)
    audit_log('MAINTENANCE_UPDATE', session['user'], json.dumps(data))
    
    return jsonify({'success': True, 'message': 'Maintenance settings saved!'})

@app.route('/admin/api/maintenance/toggle', methods=['POST'])
@login_required
@admin_required
def admin_toggle_maintenance():
    maintenance = load_maintenance()
    maintenance['enabled'] = not maintenance.get('enabled', False)
    
    if maintenance['enabled']:
        maintenance['started_at'] = str(datetime.now())
    
    save_maintenance(maintenance)
    status = 'enabled' if maintenance['enabled'] else 'disabled'
    audit_log('MAINTENANCE_TOGGLE', session['user'], f"Status: {status}")
    
    return jsonify({'success': True, 'message': f'Maintenance mode {status}!', 'enabled': maintenance['enabled']})

# ============================================
# ADMIN RESOURCES API
# ============================================
@app.route('/admin/resources')
@login_required
@admin_required
def admin_resources_page():
    return render_template('admin_resources.html')

@app.route('/admin/api/resources/list')
@login_required
@admin_required
def admin_get_resources():
    resources = load_resources()
    return jsonify({'success': True, 'resources': resources})

@app.route('/admin/api/resources/create', methods=['POST'])
@login_required
@admin_required
def admin_create_resource():
    data = request.get_json()
    resource_type = data.get('type', '')
    resource_id = data.get('id', '').strip().lower()
    name = sanitize_input(data.get('name', ''))
    price = int(data.get('price', 0))
    
    if resource_type not in ['ram', 'cpu', 'disk']:
        return jsonify({'error': 'Invalid resource type!'}), 400
    
    if not resource_id or not re.match(r'^[a-zA-Z0-9_]+$', resource_id):
        return jsonify({'error': 'Invalid resource ID!'}), 400
    
    if price < 0:
        return jsonify({'error': 'Price cannot be negative!'}), 400
    
    resources = load_resources()
    
    for r in resources.get(resource_type, []):
        if r['id'] == resource_id:
            return jsonify({'error': 'Resource ID already exists!'}), 400
    
    new_resource = {
        'id': resource_id,
        'name': name,
        'price': price,
        'active': True
    }
    
    if resource_type == 'ram':
        new_resource['size'] = data.get('size', '512MB')
    elif resource_type == 'cpu':
        new_resource['limit'] = int(data.get('limit', 50))
    elif resource_type == 'disk':
        new_resource['size'] = data.get('size', '1GB')
    
    resources[resource_type].append(new_resource)
    save_resources(resources)
    audit_log('RESOURCE_CREATE', session['user'], f"{resource_type}: {resource_id}")
    
    return jsonify({'success': True, 'message': 'Resource created!', 'resource': new_resource})

@app.route('/admin/api/resources/update/<resource_type>/<resource_id>', methods=['PUT'])
@login_required
@admin_required
def admin_update_resource(resource_type, resource_id):
    data = request.get_json()
    resources = load_resources()
    
    for r in resources.get(resource_type, []):
        if r['id'] == resource_id:
            if 'name' in data:
                r['name'] = sanitize_input(data['name'])
            if 'price' in data:
                price = int(data['price'])
                if price < 0:
                    return jsonify({'error': 'Price cannot be negative!'}), 400
                r['price'] = price
            if 'active' in data:
                r['active'] = data['active']
            if 'size' in data:
                r['size'] = data['size']
            if 'limit' in data:
                r['limit'] = int(data['limit'])
            save_resources(resources)
            audit_log('RESOURCE_UPDATE', session['user'], f"{resource_type}: {resource_id}")
            return jsonify({'success': True, 'message': 'Updated!'})
    
    return jsonify({'error': 'Resource not found!'}), 404

@app.route('/admin/api/resources/delete/<resource_type>/<resource_id>', methods=['DELETE'])
@login_required
@admin_required
def admin_delete_resource(resource_type, resource_id):
    resources = load_resources()
    resources[resource_type] = [r for r in resources.get(resource_type, []) if r['id'] != resource_id]
    save_resources(resources)
    audit_log('RESOURCE_DELETE', session['user'], f"{resource_type}: {resource_id}")
    
    return jsonify({'success': True, 'message': 'Deleted!'})

@app.route('/admin/api/resources/toggle/<resource_type>/<resource_id>', methods=['POST'])
@login_required
@admin_required
def admin_toggle_resource(resource_type, resource_id):
    resources = load_resources()
    for r in resources.get(resource_type, []):
        if r['id'] == resource_id:
            r['active'] = not r.get('active', True)
            save_resources(resources)
            audit_log('RESOURCE_TOGGLE', session['user'], f"{resource_type}: {resource_id} -> {r['active']}")
            return jsonify({'success': True, 'active': r['active']})
    
    return jsonify({'error': 'Not found!'}), 404

# ============================================
# ADMIN PORT MANAGEMENT
# ============================================
@app.route('/admin/ports')
@login_required
@admin_required
def admin_ports_page():
    return render_template('admin_ports.html')

@app.route('/admin/api/ports/list')
@login_required
@admin_required
def admin_get_ports():
    used_ports = get_all_used_ports()
    
    system_ports = []
    for conn in psutil.net_connections():
        if conn.laddr.port in range(5000, 6001):
            system_ports.append({
                'port': conn.laddr.port,
                'pid': conn.pid,
                'status': conn.status,
                'type': 'system'
            })
    
    return jsonify({
        'success': True,
        'allocated_ports': used_ports,
        'system_ports': system_ports,
        'total_used': len(used_ports),
        'available_range': '5001-6000'
    })

@app.route('/admin/api/ports/assign', methods=['POST'])
@login_required
@admin_required
def admin_assign_port():
    data = request.get_json()
    server_id = data.get('server_id', '')
    port = int(data.get('port', 0))
    
    if not server_id or not port:
        return jsonify({'error': 'Server ID and Port required!'}), 400
    
    if port < 5001 or port > 6000:
        return jsonify({'error': 'Port must be between 5001-6000!'}), 400
    
    assigned_port, error = assign_port(server_id, port)
    if error:
        return jsonify({'error': error}), 400
    
    audit_log('PORT_ASSIGN', session['user'], f"Server: {server_id}, Port: {assigned_port}")
    return jsonify({'success': True, 'message': f'Port {assigned_port} assigned to {server_id}!', 'port': assigned_port})

@app.route('/admin/api/ports/release/<int:port>', methods=['POST'])
@login_required
@admin_required
def admin_release_port(port):
    global PORT_ALLOCATIONS
    if port in PORT_ALLOCATIONS:
        server_id = PORT_ALLOCATIONS[port].get('server_id', '')
        del PORT_ALLOCATIONS[port]
        save_port_allocations()
        audit_log('PORT_RELEASE', session['user'], f"Port: {port}, Server: {server_id}")
        return jsonify({'success': True, 'message': f'Port {port} released from {server_id}!'})
    
    return jsonify({'error': 'Port not allocated!'}), 404

@app.route('/admin/api/ports/release/server/<server_id>', methods=['POST'])
@login_required
@admin_required
def admin_release_server_port(server_id):
    port = remove_port_assignment(server_id)
    if port:
        audit_log('PORT_RELEASE_SERVER', session['user'], f"Server: {server_id}, Port: {port}")
        return jsonify({'success': True, 'message': f'Port {port} released from {server_id}!'})
    
    return jsonify({'error': 'No port assigned to this server!'}), 404

# ============================================
# AUTO CLEANUP SYSTEM
# ============================================
def auto_delete_expired_servers():
    GRACE_DAYS = 3
    
    while True:
        time.sleep(86400)
        
        try:
            users = load_users()
            current_time = datetime.now()
            deleted_count = 0
            
            for username, user_data in users.items():
                if username == 'admin':
                    continue
                
                servers = user_data.get('servers', [])
                active_servers = []
                
                for server in servers:
                    expiry = server.get('expiry', '')
                    if expiry:
                        try:
                            exp_date = datetime.strptime(expiry, '%Y-%m-%d %H:%M:%S.%f')
                            days_expired = (current_time - exp_date).days
                            
                            if days_expired > GRACE_DAYS:
                                server_id = server.get('server_id')
                                
                                if server.get('pid'):
                                    stop_bot_process(server['pid'])
                                
                                try:
                                    server_dir = get_server_dir(server_id)
                                    if os.path.exists(server_dir):
                                        shutil.rmtree(server_dir)
                                except:
                                    pass
                                
                                remove_port_assignment(server_id)
                                
                                deleted_count += 1
                                logger.info(f"[AUTO-DELETE] Deleted expired server {server_id} for user {username}")
                                audit_log('SERVER_AUTO_DELETE', username, f"Server: {server_id}, Expired: {days_expired} days")
                                continue
                        except:
                            pass
                
                    active_servers.append(server)
                
                user_data['servers'] = active_servers
            
            if deleted_count > 0:
                save_users(users)
                logger.info(f"[AUTO-DELETE] Deleted {deleted_count} expired servers")
                
        except Exception as e:
            logger.error(f"[AUTO-DELETE] Error: {str(e)}")

def auto_cleanup_expired_ports():
    while True:
        time.sleep(3600)
        
        try:
            users = load_users()
            current_time = datetime.now()
            cleaned = 0
            
            for username, user_data in users.items():
                if username == 'admin':
                    continue
                
                servers = user_data.get('servers', [])
                for server in servers:
                    expiry = server.get('expiry', '')
                    if expiry:
                        try:
                            exp_date = datetime.strptime(expiry, '%Y-%m-%d %H:%M:%S.%f')
                            if current_time > exp_date:
                                server_id = server.get('server_id')
                                
                                if server.get('pid'):
                                    stop_bot_process(server['pid'])
                                    server['status'] = 'stopped'
                                    server['pid'] = None
                                
                                port = remove_port_assignment(server_id)
                                if port:
                                    server['port'] = None
                                    cleaned += 1
                                    logger.info(f"[CLEANUP] Released port {port} from expired server {server_id}")
                        except:
                            pass
            
            if cleaned > 0:
                save_users(users)
                logger.info(f"[CLEANUP] Total ports freed: {cleaned}")
                
        except Exception as e:
            logger.error(f"[CLEANUP] Error: {str(e)}")

# ============================================
# REDEEM CODE SYSTEM
# ============================================
REDEEM_FILE = 'redeem_codes.json'

def load_redeem_codes():
    if not os.path.exists(REDEEM_FILE):
        default = {"codes": []}
        save_redeem_codes(default)
        return default
    with open(REDEEM_FILE, 'r', encoding='utf-8') as f:
        return json.load(f)

def save_redeem_codes(data):
    with open(REDEEM_FILE, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=4, ensure_ascii=False)

def generate_redeem_code(length=8):
    chars = string.ascii_uppercase + string.digits
    return 'YUTA-PKG-' + ''.join(secrets.choice(chars) for _ in range(length))

@app.route('/admin/redeem')
@login_required
@admin_required
def admin_redeem_page():
    packages = load_yuta_packages()
    codes = load_redeem_codes()
    return render_template('admin_redeem.html', packages=packages, codes=codes['codes'])

@app.route('/admin/api/redeem/list')
@login_required
@admin_required
def admin_list_redeem_codes():
    codes = load_redeem_codes()
    return jsonify({'success': True, 'codes': codes['codes']})

@app.route('/admin/api/redeem/create', methods=['POST'])
@login_required
@admin_required
def admin_create_redeem_code():
    data = request.get_json()
    package_id = data.get('package_id', '')
    expiry_days = int(data.get('expiry_days', 30))
    max_uses = int(data.get('max_uses', 1))
    
    if max_uses < 1 or max_uses > 100:
        return jsonify({'error': 'Max uses must be between 1 and 100'}), 400
    
    if expiry_days < 1 or expiry_days > 365:
        return jsonify({'error': 'Expiry days must be between 1 and 365'}), 400
    
    if not package_id:
        return jsonify({'error': 'Please select a package!'}), 400
    
    packages = load_yuta_packages()
    package = packages.get(package_id)
    if not package:
        return jsonify({'error': 'Package not found!'}), 400
    
    code = generate_redeem_code()
    
    codes_data = load_redeem_codes()
    new_code = {
        'code': code,
        'package_id': package_id,
        'package_name': package.get('name', package_id),
        'ram': package.get('ram', '512MB'),
        'disk': package.get('disk', '1GB'),
        'cpu_limit': package.get('cpu_limit', 50),
        'days': package.get('days', 30),
        'server_limit': package.get('server_limit', 1),
        'expiry_days': expiry_days,
        'max_uses': max_uses,
        'used_count': 0,
        'used_by': [],
        'expiry_date': str(datetime.now() + timedelta(days=expiry_days)),
        'created_by': session['user'],
        'created_at': str(datetime.now()),
        'is_active': True
    }
    codes_data['codes'].append(new_code)
    save_redeem_codes(codes_data)
    
    audit_log('REDEEM_CREATE', session['user'], f"Code: {code}, Package: {package_id}")
    
    return jsonify({
        'success': True,
        'message': 'Redeem code created successfully!',
        'code': code,
        'package_id': package_id,
        'data': new_code
    })

@app.route('/admin/api/redeem/delete/<code>', methods=['DELETE'])
@login_required
@admin_required
def admin_delete_redeem_code(code):
    codes_data = load_redeem_codes()
    codes_data['codes'] = [c for c in codes_data['codes'] if c['code'] != code]
    save_redeem_codes(codes_data)
    
    audit_log('REDEEM_DELETE', session['user'], f"Code: {code}")
    
    return jsonify({'success': True, 'message': 'Code deleted successfully!'})

@app.route('/api/redeem/apply', methods=['POST'])
@login_required
def api_apply_redeem():
    data = request.get_json()
    code = data.get('code', '').strip().upper()
    username = session['user']
    
    if not code:
        return jsonify({'status': 'error', 'message': 'Please enter a code!'}), 400
    
    if not re.match(r'^YUTA-PKG-[A-Z0-9]+$', code):
        return jsonify({'status': 'error', 'message': 'Invalid code format!'}), 400
    
    codes_data = load_redeem_codes()
    found_code = None
    for c in codes_data['codes']:
        if c['code'] == code:
            found_code = c
            break
    
    if not found_code:
        audit_log('REDEEM_INVALID', username, f"Invalid code: {code}")
        return jsonify({'status': 'error', 'message': 'Invalid code!'}), 400
    
    if not found_code.get('is_active', True):
        return jsonify({'status': 'error', 'message': 'This code is no longer active!'}), 400
    
    if found_code.get('expiry_date'):
        try:
            exp_date = datetime.strptime(found_code['expiry_date'], '%Y-%m-%d %H:%M:%S')
            if datetime.now() > exp_date:
                return jsonify({'status': 'error', 'message': 'Code has expired!'}), 400
        except:
            pass
    
    if found_code['used_count'] >= found_code['max_uses']:
        return jsonify({'status': 'error', 'message': 'Code already used maximum times!'}), 400
    
    if username in found_code['used_by']:
        return jsonify({'status': 'error', 'message': 'You already used this code!'}), 400
    
    package_id = found_code.get('package_id')
    if not package_id:
        return jsonify({'status': 'error', 'message': 'Invalid package!'}), 400
    
    packages = load_yuta_packages()
    package = packages.get(package_id)
    if not package:
        return jsonify({'status': 'error', 'message': 'Package not found!'}), 400
    
    password = generate_random_password(12)
    result, error = create_server_from_package(username, password, package_id)
    
    if error:
        return jsonify({'status': 'error', 'message': error}), 400
    
    for c in codes_data['codes']:
        if c['code'] == code:
            c['used_count'] += 1
            c['used_by'].append(username)
            break
    save_redeem_codes(codes_data)
    
    audit_log('REDEEM_SUCCESS', username, f"Code: {code}, Server: {result['server_id']}")
    
    return jsonify({
        'status': 'success',
        'message': 'Server created successfully with redeem code!',
        'server_id': result['server_id'],
        'login_url': result['login_url'],
        'username': username,
        'password': password,
        'ram': package.get('ram', 'N/A'),
        'disk': package.get('disk', 'N/A'),
        'cpu_limit': package.get('cpu_limit', 80),
        'days': package.get('days', 30)
    })

@app.route('/user/redeem')
@login_required
def user_redeem_page():
    return render_template('user_redeem.html', username=session['user'])

# ============================================
# USER UPGRADE API
# ============================================
@app.route('/user/server/<server_id>/upgrade')
@login_required
def user_upgrade_page(server_id):
    username = session['user']
    users = load_users()
    user_data = users.get(username, {})
    
    server = None
    for s in user_data.get('servers', []):
        if s.get('server_id') == server_id:
            server = s
            break
    
    if not server:
        return redirect(url_for('user_dashboard'))
    
    valid, result = check_expiry(server_id)
    if not valid:
        return render_template('error.html', error_type='expired', server_link=server_id)
    
    resources = load_resources()
    
    return render_template('user_upgrade.html', server=server, resources=resources, username=username)

@app.route('/api/user/upgrade/calculate', methods=['POST'])
@login_required
def api_calculate_upgrade():
    data = request.get_json()
    
    selected_ram = data.get('ram', '')
    selected_cpu = data.get('cpu', '')
    selected_disk = data.get('disk', '')
    
    resources = load_resources()
    total_price = 0
    items = []
    
    if selected_ram:
        for r in resources.get('ram', []):
            if r['id'] == selected_ram and r['active']:
                total_price += r['price']
                items.append({'type': 'RAM', 'name': r['name'], 'price': r['price']})
    
    if selected_cpu:
        for r in resources.get('cpu', []):
            if r['id'] == selected_cpu and r['active']:
                total_price += r['price']
                items.append({'type': 'CPU', 'name': r['name'], 'price': r['price']})
    
    if selected_disk:
        for r in resources.get('disk', []):
            if r['id'] == selected_disk and r['active']:
                total_price += r['price']
                items.append({'type': 'Disk', 'name': r['name'], 'price': r['price']})
    
    return jsonify({'success': True, 'total': total_price, 'items': items})

@app.route('/api/user/upgrade/pay', methods=['POST'])
@login_required
def api_pay_upgrade():
    data = request.get_json()
    server_id = data.get('server_id', '')
    username = session['user']
    
    users = load_users()
    user_data = users.get(username, {})
    server = None
    for s in user_data.get('servers', []):
        if s.get('server_id') == server_id:
            server = s
            break
    
    if not server:
        return jsonify({'status': 'error', 'message': 'Server not found!'}), 404
    
    valid, result = check_expiry(server_id)
    if not valid:
        return jsonify({'status': 'error', 'message': 'Server expired!'}), 410
    
    selected_ram = data.get('ram', '')
    selected_cpu = data.get('cpu', '')
    selected_disk = data.get('disk', '')
    
    resources = load_resources()
    total_price = 0
    
    if selected_ram:
        for r in resources.get('ram', []):
            if r['id'] == selected_ram:
                total_price += r['price']
    if selected_cpu:
        for r in resources.get('cpu', []):
            if r['id'] == selected_cpu:
                total_price += r['price']
    if selected_disk:
        for r in resources.get('disk', []):
            if r['id'] == selected_disk:
                total_price += r['price']
    
    if total_price <= 0:
        return jsonify({'status': 'error', 'message': 'No upgrades selected!'}), 400
    
    user_email = user_data.get('email', f"{username}@yutacloud.host")
    
    if not validate_email(user_email):
        user_email = f"{username}@yutacloud.host"
    
    settings = load_yuta_settings()
    bohudur.set_api_key(settings.get('bohudur_api_key', ''))
    
    invoice_id = f"YUTA-UPG-{secrets.token_hex(4).upper()}"
    host = request.host_url.rstrip('/')
    
    result = bohudur.create_payment(
        full_name=username, email=user_email, amount=total_price,
        order_id=invoice_id, user_id=username,
        redirect_url=f"{host}/upgrade/success", cancel_url=f"{host}/payment/cancel",
        webhook_url=f"{host}/api/upgrade/custom/webhook",
        metadata={'server_id': server_id, 'type': 'custom_upgrade',
                  'ram': selected_ram, 'cpu': selected_cpu, 'disk': selected_disk}
    )
    
    if result['success']:
        invoices = load_yuta_invoices()
        invoices.append({
            'invoice_id': invoice_id, 'transaction_id': result['transaction_id'],
            'username': username, 'amount': total_price, 'status': 'pending',
            'created_at': str(datetime.now()), 'type': 'custom_upgrade',
            'server_id': server_id, 'upgrade_ram': selected_ram,
            'upgrade_cpu': selected_cpu, 'upgrade_disk': selected_disk
        })
        save_yuta_invoices(invoices)
        audit_log('UPGRADE_PAYMENT', username, f"Server: {server_id}, Amount: {total_price}")
        return jsonify({'status': 'success', 'payment_url': result['payment_url']})
    
    return jsonify({'status': 'error', 'message': 'Payment failed!'}), 400

@app.route('/api/upgrade/custom/webhook', methods=['POST', 'GET'])
def custom_upgrade_webhook():
    if request.method == 'POST':
        data = request.get_json(silent=True) or {}
    else:
        data = request.args.to_dict()
    
    transaction_id = data.get('transaction_id', '')
    
    if transaction_id:
        invoices = load_yuta_invoices()
        for inv in invoices:
            if inv.get('transaction_id') == transaction_id and inv['status'] == 'pending' and inv.get('type') == 'custom_upgrade':
                inv['status'] = 'paid'
                inv['paid_at'] = str(datetime.now())
                
                server_id = inv.get('server_id')
                ram_id = inv.get('upgrade_ram', '')
                cpu_id = inv.get('upgrade_cpu', '')
                disk_id = inv.get('upgrade_disk', '')
                
                resources = load_resources()
                users = load_users()
                
                for uname, udata in users.items():
                    for s in udata.get('servers', []):
                        if s.get('server_id') == server_id:
                            if ram_id:
                                for r in resources.get('ram', []):
                                    if r['id'] == ram_id:
                                        s['ram'] = r['size']
                            if cpu_id:
                                for r in resources.get('cpu', []):
                                    if r['id'] == cpu_id:
                                        s['cpu_limit'] = r['limit']
                            if disk_id:
                                for r in resources.get('disk', []):
                                    if r['id'] == disk_id:
                                        s['disk'] = r['size']
                            
                            save_users(users)
                            save_yuta_invoices(invoices)
                            audit_log('UPGRADE_APPLIED', uname, f"Server: {server_id}")
                            return jsonify({'status': 'success', 'message': 'Upgrade applied!'})
    
    return jsonify({'status': 'ignored'})

@app.route('/upgrade/success')
def upgrade_success():
    paymentkey = request.args.get('paymentkey', '')
    
    if paymentkey:
        invoices = load_yuta_invoices()
        
        for inv in invoices:
            if inv.get('transaction_id') == paymentkey and inv.get('type') == 'custom_upgrade':
                
                if inv['status'] == 'pending':
                    inv['status'] = 'paid'
                    inv['paid_at'] = str(datetime.now())
                    
                    server_id = inv.get('server_id')
                    ram_id = inv.get('upgrade_ram')
                    cpu_id = inv.get('upgrade_cpu')
                    disk_id = inv.get('upgrade_disk')
                    
                    resources = load_resources()
                    users = load_users()
                    upgrade_details = []
                    
                    for uname, udata in users.items():
                        for s in udata.get('servers', []):
                            if s.get('server_id') == server_id:
                                if ram_id:
                                    for r in resources.get('ram', []):
                                        if r['id'] == ram_id:
                                            s['ram'] = r['size']
                                            upgrade_details.append(f"RAM: {r['name']}")
                                if cpu_id:
                                    for r in resources.get('cpu', []):
                                        if r['id'] == cpu_id:
                                            s['cpu_limit'] = r['limit']
                                            upgrade_details.append(f"CPU: {r['name']}")
                                if disk_id:
                                    for r in resources.get('disk', []):
                                        if r['id'] == disk_id:
                                            s['disk'] = r['size']
                                            upgrade_details.append(f"Disk: {r['name']}")
                                
                                save_users(users)
                                break
                    
                    save_yuta_invoices(invoices)
                    audit_log('UPGRADE_SUCCESS', inv.get('username'), f"Server: {server_id}, Upgrades: {upgrade_details}")
                    
                    return render_template('upgrade_success.html',
                        transaction_id=paymentkey,
                        server_id=server_id,
                        amount=inv.get('amount', 0),
                        upgrades=", ".join(upgrade_details) if upgrade_details else "Applied successfully!"
                    )
                
                elif inv['status'] == 'paid':
                    return render_template('upgrade_success.html',
                        transaction_id=paymentkey,
                        server_id=inv.get('server_id', ''),
                        amount=inv.get('amount', 0),
                        already_paid=True
                    )
    
    return render_template('upgrade_success.html')
    

# ============================================
# BACKUP CONFIGURATION
# ============================================

BACKUP_DIR = 'backups'
os.makedirs(BACKUP_DIR, exist_ok=True)

BACKUP_CONFIG = {
    'auto_backup_enabled': True,
    'auto_backup_interval': 24,  # ঘন্টা
    'max_backups': 10,  # সর্বোচ্চ ব্যাকআপ সংখ্যা
    'backup_retention_days': 30,  # কত দিনের ব্যাকআপ রাখবে
    'compress_backups': True,
    'backup_types': ['full', 'data_only', 'bots_only']
}

# ============================================
# BACKUP FUNCTIONS
# ============================================

def create_backup(backup_type='full'):
    """Create a full system backup with smart features"""
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    backup_file = os.path.join(BACKUP_DIR, f'yutacloud_backup_{backup_type}_{timestamp}.zip')
    
    files_to_backup = {
        'data': [
            'users.json',
            'yuta_settings.json',
            'yuta_packages.json',
            'yuta_invoices.json',
            'yuta_free_trials.json',
            'yuta_resources.json',
            'yuta_maintenance.json',
            'port_allocations.json',
            'nodes.json',
            'redeem_codes.json',
            'audit.log'
        ],
        'bots': 'bots',
        'templates': 'templates'
    }
    
    try:
        with zipfile.ZipFile(backup_file, 'w', zipfile.ZIP_DEFLATED) as zipf:
            # Backup based on type
            if backup_type in ['full', 'data_only']:
                # Backup JSON files
                for file in files_to_backup['data']:
                    if os.path.exists(file):
                        zipf.write(file, f'data/{file}')
                        logger.info(f"📁 Added {file}")
            
            if backup_type in ['full', 'bots_only']:
                # Backup bots directory
                if os.path.exists(files_to_backup['bots']):
                    for root, dirs, files in os.walk(files_to_backup['bots']):
                        for file in files:
                            file_path = os.path.join(root, file)
                            arcname = os.path.join('bots', os.path.relpath(file_path, files_to_backup['bots']))
                            zipf.write(file_path, arcname)
                    logger.info("📁 Added bots directory")
            
            if backup_type == 'full':
                # Backup templates
                if os.path.exists(files_to_backup['templates']):
                    for root, dirs, files in os.walk(files_to_backup['templates']):
                        for file in files:
                            file_path = os.path.join(root, file)
                            arcname = os.path.join('templates', os.path.relpath(file_path, files_to_backup['templates']))
                            zipf.write(file_path, arcname)
                    logger.info("📁 Added templates directory")
            
            # Add backup info
            backup_info = {
                'timestamp': str(datetime.now()),
                'version': '2.0.0',
                'type': backup_type,
                'files_count': len(zipf.namelist()),
                'users_count': len(load_users()),
                'servers_count': sum(len(u.get('servers', [])) for u in load_users().values()),
                'size_mb': 0
            }
            zipf.writestr('backup_info.json', json.dumps(backup_info, indent=4))
        
        # Get actual size
        file_size = os.path.getsize(backup_file) / (1024 * 1024)
        
        # Update backup info with actual size
        with zipfile.ZipFile(backup_file, 'a') as zipf:
            backup_info['size_mb'] = round(file_size, 2)
            zipf.writestr('backup_info.json', json.dumps(backup_info, indent=4))
        
        # Clean old backups
        clean_old_backups()
        
        logger.info(f"✅ Backup created: {backup_file} ({file_size:.2f} MB)")
        
        # Send notification
        send_backup_notification(backup_file, backup_type)
        
        return {
            'success': True,
            'file': backup_file,
            'size': file_size,
            'type': backup_type,
            'timestamp': timestamp
        }
        
    except Exception as e:
        logger.error(f"❌ Backup failed: {str(e)}")
        return {'success': False, 'error': str(e)}

def clean_old_backups():
    """Smart backup cleanup - keep only recent backups"""
    try:
        backups = list_backups()
        
        # Remove by count
        if len(backups) > BACKUP_CONFIG['max_backups']:
            for backup in backups[BACKUP_CONFIG['max_backups']:]:
                file_path = os.path.join(BACKUP_DIR, backup['filename'])
                os.remove(file_path)
                logger.info(f"🗑️ Removed old backup (count): {backup['filename']}")
        
        # Remove by age
        cutoff_date = datetime.now() - timedelta(days=BACKUP_CONFIG['backup_retention_days'])
        for backup in backups:
            backup_date = datetime.strptime(backup['timestamp'], '%Y%m%d_%H%M%S')
            if backup_date < cutoff_date:
                file_path = os.path.join(BACKUP_DIR, backup['filename'])
                os.remove(file_path)
                logger.info(f"🗑️ Removed old backup (age): {backup['filename']}")
        
        # Keep at least one backup of each type
        backup_types = set()
        for backup in list_backups():
            if '_full_' in backup['filename']:
                backup_types.add('full')
            elif '_data_only_' in backup['filename']:
                backup_types.add('data_only')
            elif '_bots_only_' in backup['filename']:
                backup_types.add('bots_only')
        
        # Ensure we have at least one of each type
        for backup_type in ['full', 'data_only', 'bots_only']:
            if backup_type not in backup_types:
                create_backup(backup_type)
                
    except Exception as e:
        logger.error(f"❌ Backup cleanup failed: {str(e)}")

def list_backups():
    """List all available backups with smart sorting"""
    backups = []
    for file in os.listdir(BACKUP_DIR):
        if file.endswith('.zip'):
            file_path = os.path.join(BACKUP_DIR, file)
            size = os.path.getsize(file_path) / (1024 * 1024)
            modified = datetime.fromtimestamp(os.path.getmtime(file_path))
            
            # Get backup info
            backup_type = 'full'
            if '_data_only_' in file:
                backup_type = 'data_only'
            elif '_bots_only_' in file:
                backup_type = 'bots_only'
            
            try:
                with zipfile.ZipFile(file_path, 'r') as zipf:
                    if 'backup_info.json' in zipf.namelist():
                        info = json.loads(zipf.read('backup_info.json'))
                        backups.append({
                            'filename': file,
                            'size': round(size, 2),
                            'modified': modified.strftime('%Y-%m-%d %H:%M:%S'),
                            'timestamp': info.get('timestamp', file.split('_')[2:4]),
                            'type': info.get('type', backup_type),
                            'users': info.get('users_count', 0),
                            'servers': info.get('servers_count', 0),
                            'files_count': info.get('files_count', 0)
                        })
                    else:
                        backups.append({
                            'filename': file,
                            'size': round(size, 2),
                            'modified': modified.strftime('%Y-%m-%d %H:%M:%S'),
                            'timestamp': file.split('_')[2:4],
                            'type': backup_type,
                            'users': 0,
                            'servers': 0,
                            'files_count': 0
                        })
            except:
                backups.append({
                    'filename': file,
                    'size': round(size, 2),
                    'modified': modified.strftime('%Y-%m-%d %H:%M:%S'),
                    'timestamp': 'Unknown',
                    'type': backup_type,
                    'users': 0,
                    'servers': 0,
                    'files_count': 0
                })
    
    return sorted(backups, key=lambda x: x['modified'], reverse=True)

def restore_backup(backup_file):
    """Smart restore from backup"""
    if not os.path.exists(backup_file):
        return False, "Backup file not found"
    
    # Verify backup integrity
    if not zipfile.is_zipfile(backup_file):
        return False, "Invalid backup file"
    
    # Create restore directory
    restore_dir = os.path.join(BACKUP_DIR, 'restore_temp')
    os.makedirs(restore_dir, exist_ok=True)
    
    try:
        with zipfile.ZipFile(backup_file, 'r') as zipf:
            # Validate backup content
            if 'backup_info.json' not in zipf.namelist():
                return False, "Invalid backup: missing info file"
            
            zipf.extractall(restore_dir)
        
        # Restore files
        restored_items = []
        
        # Restore data files
        data_dir = os.path.join(restore_dir, 'data')
        if os.path.exists(data_dir):
            for file in os.listdir(data_dir):
                src = os.path.join(data_dir, file)
                dst = os.path.join('.', file)
                shutil.copy2(src, dst)
                restored_items.append(file)
                logger.info(f"✅ Restored {file}")
        
        # Restore bots
        bots_restore = os.path.join(restore_dir, 'bots')
        if os.path.exists(bots_restore):
            if os.path.exists('bots'):
                shutil.rmtree('bots')
            shutil.copytree(bots_restore, 'bots')
            restored_items.append('bots/')
            logger.info("✅ Restored bots directory")
        
        # Restore templates
        templates_restore = os.path.join(restore_dir, 'templates')
        if os.path.exists(templates_restore):
            if os.path.exists('templates'):
                shutil.rmtree('templates')
            shutil.copytree(templates_restore, 'templates')
            restored_items.append('templates/')
            logger.info("✅ Restored templates directory")
        
        # Cleanup
        shutil.rmtree(restore_dir)
        
        audit_log('BACKUP_RESTORED', session.get('user', 'system'), 
                 f"Backup: {os.path.basename(backup_file)}, Items: {len(restored_items)}")
        
        return True, f"Restored {len(restored_items)} items successfully!"
        
    except Exception as e:
        shutil.rmtree(restore_dir)
        return False, f"Restore failed: {str(e)}"

def get_backup_stats():
    """Get smart backup statistics"""
    backups = list_backups()
    
    stats = {
        'total_backups': len(backups),
        'total_size_mb': sum(b['size'] for b in backups),
        'by_type': {},
        'oldest': None,
        'newest': None,
        'storage_used_percent': 0,
        'daily_backups': [],
        'weekly_backups': [],
        'monthly_backups': []
    }
    
    # Group by type
    for backup in backups:
        backup_type = backup.get('type', 'full')
        if backup_type not in stats['by_type']:
            stats['by_type'][backup_type] = 0
        stats['by_type'][backup_type] += 1
    
    # Get oldest and newest
    if backups:
        stats['newest'] = backups[0]
        stats['oldest'] = backups[-1]
    
    # Storage usage (assuming 1GB limit)
    storage_limit_mb = 1024
    stats['storage_used_percent'] = round((stats['total_size_mb'] / storage_limit_mb) * 100, 1)
    
    # Categorize backups
    now = datetime.now()
    for backup in backups:
        backup_date = datetime.strptime(backup['modified'], '%Y-%m-%d %H:%M:%S')
        days_diff = (now - backup_date).days
        
        if days_diff <= 1:
            stats['daily_backups'].append(backup['filename'])
        elif days_diff <= 7:
            stats['weekly_backups'].append(backup['filename'])
        else:
            stats['monthly_backups'].append(backup['filename'])
    
    return stats

def send_backup_notification(backup_file, backup_type):
    """Send notification about backup"""
    try:
        # Send to Telegram (if configured)
        settings = load_yuta_settings()
        if settings.get('telegram_bot_token') and settings.get('telegram_chat_id'):
            import requests
            message = f"📦 Backup Created\nType: {backup_type}\nFile: {os.path.basename(backup_file)}\nTime: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
            requests.post(
                f"https://api.telegram.org/bot{settings['telegram_bot_token']}/sendMessage",
                json={'chat_id': settings['telegram_chat_id'], 'text': message}
            )
    except:
        pass

# ============================================
# AUTO BACKUP SCHEDULER (SMART)
# ============================================

def smart_auto_backup():
    """Intelligent auto backup scheduler"""
    while True:
        try:
            if not BACKUP_CONFIG['auto_backup_enabled']:
                time.sleep(3600)
                continue
            
            # Check last backup time
            backups = list_backups()
            if backups:
                last_backup = datetime.strptime(backups[0]['modified'], '%Y-%m-%d %H:%M:%S')
                hours_since = (datetime.now() - last_backup).total_seconds() / 3600
                
                if hours_since < BACKUP_CONFIG['auto_backup_interval']:
                    time.sleep(1800)  # Check every 30 minutes
                    continue
            
            # Create smart backup based on changes
            backup_type = 'full'
            
            # Check if only data changed
            if os.path.exists('audit.log'):
                with open('audit.log', 'r') as f:
                    lines = f.readlines()
                    if lines:
                        last_line = lines[-1]
                        if 'SERVER_CREATE' in last_line or 'SERVER_DELETE' in last_line:
                            backup_type = 'data_only'
            
            # Create backup
            result = create_backup(backup_type)
            if result['success']:
                logger.info(f"✅ Auto backup completed: {result['file']}")
            
            # Clean old backups
            clean_old_backups()
            
            # Check storage health
            check_backup_health()
            
            # Wait for next interval
            time.sleep(BACKUP_CONFIG['auto_backup_interval'] * 3600)
            
        except Exception as e:
            logger.error(f"❌ Auto backup error: {str(e)}")
            time.sleep(3600)

def check_backup_health():
    """Check backup health and integrity"""
    backups = list_backups()
    
    # Check if we have recent backups
    if backups:
        last_backup = datetime.strptime(backups[0]['modified'], '%Y-%m-%d %H:%M:%S')
        hours_since = (datetime.now() - last_backup).total_seconds() / 3600
        
        if hours_since > BACKUP_CONFIG['auto_backup_interval'] * 2:
            logger.warning("⚠️ No recent backups! Creating emergency backup...")
            create_backup('full')
    
    # Check backup file integrity
    for backup in backups[:5]:  # Check only recent 5
        file_path = os.path.join(BACKUP_DIR, backup['filename'])
        if not zipfile.is_zipfile(file_path):
            logger.error(f"❌ Corrupt backup found: {backup['filename']}")
            os.remove(file_path)
            logger.info(f"🗑️ Removed corrupt backup: {backup['filename']}")

# ============================================
# BACKUP ROUTES
# ============================================

@app.route('/admin/backup')
@login_required
@admin_required
def admin_backup_page():
    """Admin backup management page"""
    backups = list_backups()
    stats = get_backup_stats()
    return render_template('admin_backup.html', backups=backups, stats=stats)

@app.route('/admin/api/backup/create', methods=['POST'])
@login_required
@admin_required
def api_create_backup():
    """Create a new backup with type selection"""
    data = request.get_json() or {}
    backup_type = data.get('type', 'full')
    
    if backup_type not in ['full', 'data_only', 'bots_only']:
        return jsonify({'error': 'Invalid backup type'}), 400
    
    try:
        result = create_backup(backup_type)
        if result['success']:
            audit_log('BACKUP_CREATED', session['user'], 
                     f"Type: {backup_type}, File: {os.path.basename(result['file'])}")
            return jsonify({
                'success': True,
                'message': f'Backup created successfully!',
                'file': result['file'],
                'size': result['size'],
                'type': backup_type
            })
        else:
            return jsonify({'error': result['error']}), 500
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/admin/api/backup/list')
@login_required
@admin_required
def api_list_backups():
    """List all backups with smart sorting"""
    backups = list_backups()
    stats = get_backup_stats()
    return jsonify({
        'backups': backups,
        'stats': stats,
        'config': BACKUP_CONFIG
    })

@app.route('/admin/api/backup/restore', methods=['POST'])
@login_required
@admin_required
def api_restore_backup():
    """Restore from a backup with confirmation"""
    data = request.get_json()
    filename = data.get('filename', '')
    
    if not filename:
        return jsonify({'error': 'Filename required'}), 400
    
    # Security: prevent path traversal
    if '..' in filename or not filename.endswith('.zip'):
        return jsonify({'error': 'Invalid filename'}), 400
    
    backup_file = os.path.join(BACKUP_DIR, filename)
    success, message = restore_backup(backup_file)
    
    if success:
        audit_log('BACKUP_RESTORED', session['user'], f"File: {filename}")
        return jsonify({'success': True, 'message': message})
    else:
        return jsonify({'error': message}), 500

@app.route('/admin/api/backup/delete', methods=['POST'])
@login_required
@admin_required
def api_delete_backup():
    """Delete a backup file"""
    data = request.get_json()
    filename = data.get('filename', '')
    
    if not filename:
        return jsonify({'error': 'Filename required'}), 400
    
    if '..' in filename or not filename.endswith('.zip'):
        return jsonify({'error': 'Invalid filename'}), 400
    
    file_path = os.path.join(BACKUP_DIR, filename)
    if os.path.exists(file_path):
        os.remove(file_path)
        audit_log('BACKUP_DELETED', session['user'], f"File: {filename}")
        return jsonify({'success': True, 'message': 'Backup deleted!'})
    
    return jsonify({'error': 'Backup not found'}), 404

@app.route('/admin/api/backup/download/<filename>')
@login_required
@admin_required
def api_download_backup(filename):
    """Download a backup file with security checks"""
    if '..' in filename or not filename.endswith('.zip'):
        return jsonify({'error': 'Invalid filename'}), 400
    
    file_path = os.path.join(BACKUP_DIR, filename)
    if os.path.exists(file_path):
        # Check file size before download
        file_size = os.path.getsize(file_path) / (1024 * 1024)
        if file_size > 500:  # 500MB limit
            return jsonify({'error': 'File too large for download (max 500MB)'}), 400
        
        audit_log('BACKUP_DOWNLOADED', session['user'], f"File: {filename}")
        return send_file(file_path, as_attachment=True, max_age=0)
    
    return jsonify({'error': 'Backup not found'}), 404

@app.route('/admin/api/backup/config', methods=['GET', 'POST'])
@login_required
@admin_required
def api_backup_config():
    """Get or update backup configuration"""
    global BACKUP_CONFIG
    
    if request.method == 'GET':
        return jsonify({'config': BACKUP_CONFIG})
    
    data = request.get_json()
    
    # Update config
    for key in ['auto_backup_enabled', 'auto_backup_interval', 'max_backups', 'backup_retention_days']:
        if key in data:
            if key == 'auto_backup_enabled':
                BACKUP_CONFIG[key] = bool(data[key])
            elif key in ['auto_backup_interval', 'max_backups', 'backup_retention_days']:
                value = int(data[key])
                if value < 1:
                    return jsonify({'error': f'{key} must be at least 1'}), 400
                BACKUP_CONFIG[key] = value
    
    audit_log('BACKUP_CONFIG_UPDATED', session['user'], json.dumps(data))
    return jsonify({'success': True, 'message': 'Configuration updated!'})

@app.route('/admin/api/backup/health')
@login_required
@admin_required
def api_backup_health():
    """Get backup health status"""
    backups = list_backups()
    
    health = {
        'status': 'healthy',
        'last_backup': None,
        'backup_count': len(backups),
        'total_size': sum(b['size'] for b in backups),
        'integrity': True,
        'warnings': []
    }
    
    if backups:
        health['last_backup'] = backups[0]['modified']
        
        # Check if backups are recent
        last_date = datetime.strptime(backups[0]['modified'], '%Y-%m-%d %H:%M:%S')
        hours_since = (datetime.now() - last_date).total_seconds() / 3600
        
        if hours_since > BACKUP_CONFIG['auto_backup_interval'] * 2:
            health['status'] = 'warning'
            health['warnings'].append('No recent backups found')
        
        # Check integrity of recent backups
        for backup in backups[:3]:
            file_path = os.path.join(BACKUP_DIR, backup['filename'])
            if not zipfile.is_zipfile(file_path):
                health['status'] = 'degraded'
                health['integrity'] = False
                health['warnings'].append(f'Corrupt backup: {backup["filename"]}')
                break
    
    return jsonify({'health': health})

# ============================================
# START BACKUP THREAD
# ============================================

def start_backup_system():
    """Start the smart backup system"""
    try:
        # Create backup directory if not exists
        os.makedirs(BACKUP_DIR, exist_ok=True)
        
        # Create initial backup if none exists
        if not list_backups():
            create_backup('full')
        
        # Start auto backup thread
        backup_thread = threading.Thread(target=smart_auto_backup, daemon=True)
        backup_thread.start()
        logger.info("[BACKUP] Smart backup system started")
        
        logger.info(f"[BACKUP] Auto backup: {BACKUP_CONFIG['auto_backup_enabled']}")
        logger.info(f"[BACKUP] Interval: {BACKUP_CONFIG['auto_backup_interval']} hours")
        logger.info(f"[BACKUP] Max backups: {BACKUP_CONFIG['max_backups']}")
        logger.info(f"[BACKUP] Retention: {BACKUP_CONFIG['backup_retention_days']} days")
        
    except Exception as e:
        logger.error(f"[BACKUP] Failed to start: {str(e)}")

# ============================================
# SERVER RENEW SYSTEM
# ============================================
@app.route('/api/server/renew', methods=['POST'])
@login_required
def api_renew_server():
    data = request.get_json()
    server_id = data.get('server_id', '')
    package_id = data.get('package_id', '')
    
    server, username = get_server_by_id(server_id)
    if not server:
        return jsonify({'status': 'error', 'message': 'Server not found!'}), 404
    
    packages = load_yuta_packages()
    package = packages.get(package_id)
    if not package:
        return jsonify({'status': 'error', 'message': 'Package not found!'}), 400
    
    if package.get('is_free'):
        return jsonify({'status': 'error', 'message': 'Cannot renew with free package!'}), 400
    
    users = load_users()
    user_data = users.get(username, {})
    user_email = user_data.get('email', '')
    
    if not user_email:
        user_email = f"{username}@yutacloud.host"
    
    if not validate_email(user_email):
        user_email = f"{username}@yutacloud.host"
    
    amount = package['price']
    
    settings = load_yuta_settings()
    bohudur.set_api_key(settings.get('bohudur_api_key', ''))
    
    if not settings.get('bohudur_api_key'):
        return jsonify({'status': 'error', 'message': 'Payment gateway not configured!'}), 400
    
    invoice_id = f"YUTA-RENEW-{secrets.token_hex(4).upper()}"
    host = request.host_url.rstrip('/')
    
    result = bohudur.create_payment(
        full_name=username, email=user_email, amount=amount,
        order_id=invoice_id, user_id=username,
        redirect_url=f"{host}/renew/success", cancel_url=f"{host}/payment/cancel",
        webhook_url=f"{host}/api/renew/webhook/success",
        metadata={'server_id': server_id, 'package_id': package_id, 'type': 'renew'}
    )
    
    if result['success']:
        invoices = load_yuta_invoices()
        invoices.append({
            'invoice_id': invoice_id, 'transaction_id': result['transaction_id'],
            'username': username, 'email': user_email, 'package_id': package_id,
            'amount': amount, 'status': 'pending', 'created_at': str(datetime.now()),
            'type': 'renew', 'server_id': server_id
        })
        save_yuta_invoices(invoices)
        audit_log('RENEW_PAYMENT', username, f"Server: {server_id}, Package: {package_id}")
        
        return jsonify({'status': 'success', 'payment_url': result['payment_url'], 'invoice_id': invoice_id})
    
    return jsonify({'status': 'error', 'message': result.get('error', 'Payment failed!')}), 400

@app.route('/api/renew/webhook/success', methods=['POST', 'GET'])
def renew_webhook():
    if request.method == 'POST':
        data = request.get_json(silent=True) or {}
    else:
        data = request.args.to_dict()
    
    transaction_id = data.get('transaction_id', '')
    
    if transaction_id:
        invoices = load_yuta_invoices()
        for inv in invoices:
            if inv.get('transaction_id') == transaction_id and inv['status'] == 'pending' and inv.get('type') == 'renew':
                inv['status'] = 'paid'
                inv['paid_at'] = str(datetime.now())
                
                server_id = inv.get('server_id')
                package_id = inv.get('package_id')
                
                users = load_users()
                for uname, udata in users.items():
                    for s in udata.get('servers', []):
                        if s.get('server_id') == server_id:
                            packages = load_yuta_packages()
                            pkg = packages.get(package_id, {})
                            days = pkg.get('days', 30)
                            
                            try:
                                current_expiry_date = datetime.strptime(s.get('expiry', str(datetime.now())), '%Y-%m-%d %H:%M:%S.%f')
                            except:
                                current_expiry_date = datetime.now()
                            
                            new_expiry = current_expiry_date + timedelta(days=days)
                            s['expiry'] = str(new_expiry)
                            s['package'] = package_id
                            s['ram'] = pkg.get('ram', s.get('ram'))
                            s['disk'] = pkg.get('disk', s.get('disk'))
                            s['cpu_limit'] = pkg.get('cpu_limit', s.get('cpu_limit'))
                            
                            save_users(users)
                            save_yuta_invoices(invoices)
                            audit_log('RENEW_WEBHOOK', uname, f"Server: {server_id}, Days: {days}")
                            
                            return jsonify({'status': 'success', 'message': f'Server renewed for {days} days!'})
    
    return jsonify({'status': 'ignored'})

@app.route('/renew/success')
def renew_success():
    paymentkey = request.args.get('paymentkey', '')
    
    if paymentkey:
        invoices = load_yuta_invoices()
        
        for inv in invoices:
            if inv.get('transaction_id') == paymentkey and inv['status'] == 'pending' and inv.get('type') == 'renew':
                inv['status'] = 'paid'
                inv['paid_at'] = str(datetime.now())
                
                server_id = inv.get('server_id', '')
                package_id = inv.get('package_id', '')
                
                users = load_users()
                for uname, udata in users.items():
                    for s in udata.get('servers', []):
                        if s.get('server_id') == server_id:
                            packages = load_yuta_packages()
                            pkg = packages.get(package_id, {})
                            days = pkg.get('days', 30)
                            
                            try:
                                current_expiry_date = datetime.strptime(s.get('expiry', str(datetime.now())), '%Y-%m-%d %H:%M:%S.%f')
                            except:
                                current_expiry_date = datetime.now()
                            
                            new_expiry = current_expiry_date + timedelta(days=days)
                            s['expiry'] = str(new_expiry)
                            s['package'] = package_id
                            s['ram'] = pkg.get('ram', s.get('ram', 'N/A'))
                            s['disk'] = pkg.get('disk', s.get('disk', 'N/A'))
                            s['cpu_limit'] = pkg.get('cpu_limit', s.get('cpu_limit', 80))
                            
                            save_users(users)
                            save_yuta_invoices(invoices)
                            audit_log('RENEW_SUCCESS', inv.get('username'), f"Server: {server_id}, Days: {days}")
                            
                            return render_template('renew_success.html',
                                server_id=server_id, new_expiry=str(new_expiry)[:10],
                                days=str(days), amount=str(inv.get('amount', 0)),
                                transaction_id=paymentkey
                            )
        
        for inv in invoices:
            if inv.get('transaction_id') == paymentkey and inv['status'] == 'paid':
                return render_template('renew_success.html',
                    server_id=inv.get('server_id', ''), new_expiry='Already updated',
                    days='-', amount=str(inv.get('amount', 0)), already_paid=True
                )
    
    return render_template('renew_success.html')

# ============================================
# YUTA CLOUD HOSTING - SETTINGS & PACKAGES
# ============================================
def load_yuta_settings():
    if not os.path.exists(SETTINGS_FILE):
        default = {
            'site_name': 'YUTA CLOUD HOSTING',
            'bohudur_api_key': '',
            'auto_verify_payment': True,
            'currency': 'BDT',
            'trial_days': 3,
            'trial_enabled': True,
            'allow_free_only_once': True,
            'auto_delete_days': 3,
            'maintenance_mode': False
        }
        save_yuta_settings(default)
        return default
    with open(SETTINGS_FILE, 'r', encoding='utf-8') as f:
        return json.load(f)

def save_yuta_settings(data):
    with open(SETTINGS_FILE, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=4, ensure_ascii=False)

def load_yuta_packages():
    if not os.path.exists(PACKAGES_FILE):
        default = {
            'free_trial': {
                'id': 'free_trial', 'name': 'Free Trial', 'icon': '🎁',
                'price': 0, 'ram': '512MB', 'disk': '1GB', 'cpu_limit': 50,
                'days': 3, 'server_limit': 1, 'active': True, 'is_free': True,
                'features': ['1 Server', '512 MB RAM', '1 GB Disk', '3 Days Validity']
            },
            'starter': {
                'id': 'starter', 'name': 'Starter', 'icon': '🚀',
                'price': 299, 'ram': '1GB', 'disk': '5GB', 'cpu_limit': 70,
                'days': 30, 'server_limit': 3, 'active': True,
                'features': ['3 Servers', '1 GB RAM', '5 GB Disk', '30 Days Validity']
            },
            'pro': {
                'id': 'pro', 'name': 'Pro', 'icon': '⚡',
                'price': 599, 'ram': '2GB', 'disk': '10GB', 'cpu_limit': 90,
                'days': 30, 'server_limit': 10, 'active': True,
                'features': ['10 Servers', '2 GB RAM', '10 GB Disk', '30 Days Validity']
            },
            'business': {
                'id': 'business', 'name': 'Business', 'icon': '💼',
                'price': 999, 'ram': '4GB', 'disk': '20GB', 'cpu_limit': 100,
                'days': 30, 'server_limit': 25, 'active': True,
                'features': ['25 Servers', '4 GB RAM', '20 GB Disk', '30 Days Validity']
            },
            'enterprise': {
                'id': 'enterprise', 'name': 'Enterprise', 'icon': '👑',
                'price': 1999, 'ram': '8GB', 'disk': '50GB', 'cpu_limit': 100,
                'days': 365, 'server_limit': 50, 'active': True,
                'features': ['50 Servers', '8 GB RAM', '50 GB Disk', '365 Days Validity']
            }
        }
        save_yuta_packages(default)
        return default
    with open(PACKAGES_FILE, 'r', encoding='utf-8') as f:
        return json.load(f)

def save_yuta_packages(data):
    with open(PACKAGES_FILE, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=4, ensure_ascii=False)

def load_yuta_invoices():
    if not os.path.exists(INVOICES_FILE):
        save_yuta_invoices([])
        return []
    with open(INVOICES_FILE, 'r', encoding='utf-8') as f:
        return json.load(f)

def save_yuta_invoices(data):
    with open(INVOICES_FILE, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=4, ensure_ascii=False)

def load_yuta_free_trials():
    if not os.path.exists(FREE_TRIALS_FILE):
        save_yuta_free_trials({})
        return {}
    with open(FREE_TRIALS_FILE, 'r', encoding='utf-8') as f:
        return json.load(f)

def save_yuta_free_trials(data):
    with open(FREE_TRIALS_FILE, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=4, ensure_ascii=False)

def create_server_from_package(username, password, package_id, requested_port=None):
    packages = load_yuta_packages()
    package = packages.get(package_id)
    
    if not package:
        return None, 'Package not found'
    
    if not package.get('active', True):
        return None, 'Package is not active'
    
    users = load_users()
    
    if username in users:
        existing_servers = users[username].get('servers', [])
        if len(existing_servers) >= package['server_limit']:
            return None, f'Server limit reached! Max {package["server_limit"]} servers allowed.'
    
    server_id = secrets.token_hex(4).upper()
    expiry_date = datetime.now() + timedelta(days=package['days'])
    
    create_default_files(get_server_dir(server_id))
    
    host = request.host
    is_local = host.startswith('localhost') or host.startswith('127.0.0.1') or host.startswith('192.168')
    scheme = 'http' if is_local else 'https'
    full_url = f"{scheme}://{host}/{server_id}/login"
    
    port, port_error = assign_port(server_id, requested_port)
    if port_error:
        return None, port_error
    
    assigned_node = assign_server_to_node(server_id)
    
    new_server = {
        'server_id': server_id,
        'login_url': f"/{server_id}/login",
        'dashboard_url': f"/{server_id}/home",
        'full_link': full_url,
        'type': 'python',
        'ram': package['ram'],
        'disk': package['disk'],
        'status': 'stopped',
        'pid': None,
        'port': port,
        'created': str(datetime.now()),
        'expiry': str(expiry_date),
        'main_file': 'main.py',
        'requirements_file': 'requirements.txt',
        'cpu_limit': package['cpu_limit'],
        'rate_limit_exceeded': False,
        'stopped_by_user': False,
        'package': package_id,
        'node': assigned_node
    }
    
    if username not in users:
        # New user: save with provided password
        users[username] = {
            'password': password,
            'role': 'user', 
            'servers': [new_server],
            'created_at': str(datetime.now()),
            'total_spent': 0
        }
    else:
        # Existing user: Just add server, DO NOT change password
        if 'servers' not in users[username]:
            users[username]['servers'] = []
        users[username]['servers'].append(new_server)
        # ❌ REMOVE THIS LINE - Don't overwrite password
        # users[username]['password'] = password
    
    save_users(users)
    audit_log('SERVER_CREATE', username, f"Server: {server_id}, Package: {package_id}, Node: {assigned_node}")
    
    return {
        'server_id': server_id,
        'username': username,
        'login_url': new_server['login_url'],
        'full_url': new_server['full_link'],
        'port': port,
        'node': assigned_node
    }, None

# ============================================
# RATE LIMITER
# ============================================
class RateLimiter:
    def check_rate(self, server_id, limit_percent):
        if server_id not in CPU_HISTORY:
            CPU_HISTORY[server_id] = []
        users = load_users()
        server = None
        for uname, data in users.items():
            if uname == 'admin': continue
            servers = data.get('servers', [])
            if not isinstance(servers, list): continue
            for s in servers:
                if isinstance(s, dict) and s.get('server_id') == server_id:
                    server = s
                    break
        if not server or server.get('status') != 'running':
            return False, 0
        pid = server.get('pid')
        if not pid: return False, 0
        try:
            proc = psutil.Process(pid)
            cpu = proc.cpu_percent(interval=1)
            now = time.time()
            CPU_HISTORY[server_id].append({'time': now, 'cpu': cpu})
            CPU_HISTORY[server_id] = [h for h in CPU_HISTORY[server_id] if now - h['time'] < 30]
            recent = [h['cpu'] for h in CPU_HISTORY[server_id] if now - h['time'] < 10]
            if recent:
                avg_cpu = sum(recent) / len(recent)
                if avg_cpu > limit_percent:
                    return True, avg_cpu
        except:
            pass
        return False, 0

rate_limiter = RateLimiter()

# ============================================
# AUTO-RESTART
# ============================================
def should_auto_restart(server_id):
    if server_id not in CRASH_COUNT:
        CRASH_COUNT[server_id] = {'count': 0, 'last_crash': time.time()}
    crash_info = CRASH_COUNT[server_id]
    if time.time() - crash_info['last_crash'] < 60:
        if crash_info['count'] >= 3:
            return False
    else:
        crash_info['count'] = 0
    crash_info['count'] += 1
    crash_info['last_crash'] = time.time()
    return True

# ============================================
# HELPERS
# ============================================
def generate_random_password(length=12):
    chars = string.ascii_letters + string.digits + "!@#$%^&*"
    return ''.join(secrets.choice(chars) for _ in range(length))

def load_users():
    if not os.path.exists(USERS_FILE):
        default = {"admin": {"password": "yuta_005", "role": "admin"}}
        save_users(default)
        return default
    with open(USERS_FILE, 'r', encoding='utf-8') as f:
        data = json.load(f)
    if 'admin' not in data:
        data['admin'] = {"password": "yuta_005", "role": "admin"}
        save_users(data)
    return data

def save_users(data):
    with open(USERS_FILE, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=4, ensure_ascii=False)

def get_server_dir(server_id):
    server_dir = os.path.join(BOTS_DIR, server_id)
    os.makedirs(server_dir, exist_ok=True)
    return server_dir

def check_server_valid(server_id):
    users = load_users()
    for uname, data in users.items():
        if uname == 'admin': continue
        servers = data.get('servers', [])
        if not isinstance(servers, list): continue
        for s in servers:
            if isinstance(s, dict) and s.get('server_id') == server_id:
                expiry = s.get('expiry', '')
                if expiry:
                    try:
                        exp_date = datetime.strptime(expiry, '%Y-%m-%d %H:%M:%S.%f')
                        if datetime.now() > exp_date:
                            return False, "expired"
                    except:
                        pass
                return True, s
    return False, "deleted"

def get_server_by_id(server_id):
    users = load_users()
    for uname, data in users.items():
        if uname == 'admin': continue
        servers = data.get('servers', [])
        if not isinstance(servers, list): continue
        for s in servers:
            if isinstance(s, dict) and s.get('server_id') == server_id:
                return s, uname
    return None, None

def create_default_files(server_dir):
    main_py = os.path.join(server_dir, 'main.py')
    if not os.path.exists(main_py):
        with open(main_py, 'w', encoding='utf-8') as f:
            f.write('''# YUTA CLOUD HOSTING - Secure Default Bot
import time
import os
import sys

PORT = int(os.environ.get('PORT', 5000))

def main():
    print("=" * 50)
    print("🚀 YUTA CLOUD HOSTING - Secure Bot")
    print(f"📍 Port: {PORT}")
    print("=" * 50)
    
    counter = 0
    while True:
        counter += 1
        print(f"[{time.strftime('%H:%M:%S')}] Heartbeat #{counter} | Port: {PORT} | Active")
        time.sleep(10)

if __name__ == "__main__":
    main()
''')
    
    req_file = os.path.join(server_dir, 'requirements.txt')
    if not os.path.exists(req_file):
        with open(req_file, 'w', encoding='utf-8') as f:
            f.write('# Add your pip packages here\n')

# ============================================
# BOT RUNNER
# ============================================
def run_bot(server_id, main_file='main.py', requirements_file='requirements.txt'):
    server_dir = get_server_dir(server_id)
    main_path = os.path.join(server_dir, main_file)
    log_file = os.path.join(server_dir, 'output.log')
    python_exe = sys.executable
    
    def log(msg):
        try:
            with open(log_file, 'a', encoding='utf-8') as f:
                f.write(f"{msg}\n")
                f.flush()
        except:
            pass
    
    if not os.path.exists(main_path):
        return None, f"ERROR: {main_file} not found!"
    
    if os.path.exists(log_file):
        try:
            os.remove(log_file)
        except:
            open(log_file, 'w').close()
    
    ts = lambda: datetime.now().strftime('%I:%M:%S %p')
    
    server, _ = get_server_by_id(server_id)
    if not server:
        return None, "Server not found!"
    
    cpu_limit = server.get('cpu_limit', 80)
    assigned_port = server.get('port', get_server_port(server_id))
    
    log(f"[{ts()}] 🚀 Starting server...")
    log(f"[{ts()}] Rate limit: {cpu_limit}%")
    if assigned_port:
        log(f"[{ts()}] Assigned Port: {assigned_port}")
    log("")
    
    if requirements_file and requirements_file.strip():
        req_path = os.path.join(server_dir, requirements_file.strip())
        log(f"[{ts()}] 📦 Installing requirements from {requirements_file}")
        log("")
        
        if os.path.exists(req_path):
            with open(req_path, 'r', encoding='utf-8') as f:
                content = f.read().strip()
            
            lines = [l.strip() for l in content.split('\n') if l.strip() and not l.strip().startswith('#')]
            
            if lines:
                try:
                    proc = subprocess.Popen(
                        [python_exe, '-m', 'pip', 'install', '-r', os.path.abspath(req_path), '--disable-pip-version-check', '--no-cache-dir'],
                        stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                        text=True, bufsize=1, universal_newlines=True,
                        creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == 'win32' else 0
                    )
                    
                    for line in iter(proc.stdout.readline, ''):
                        if line.strip():
                            log(f"[{ts()}] {line.rstrip()}")
                    
                    proc.wait()
                    log("")
                    
                    if proc.returncode != 0:
                        log(f"[{ts()}] ⚠️ Some packages failed to install")
                    else:
                        log(f"[{ts()}] ✅ Requirements installed successfully!")
                except Exception as e:
                    log(f"[{ts()}] ❌ pip error: {str(e)}")
            else:
                log(f"[{ts()}] {requirements_file} is empty, skipping...")
        else:
            log(f"[{ts()}] {requirements_file} not found, skipping...")
    else:
        log(f"[{ts()}] No requirements file set, skipping...")
    
    log("")
    log(f"[{ts()}] 🏃 Running: python {main_file}")
    log(f"[{ts()}] Python {sys.version.split()[0]}")
    log("")
    
    try:
        main_path_abs = os.path.abspath(main_path)
        env = os.environ.copy()
        env['PYTHONIOENCODING'] = 'utf-8'
        env['PYTHONUNBUFFERED'] = '1'
        
        if assigned_port:
            env['PORT'] = str(assigned_port)
        
        proc = subprocess.Popen(
            [python_exe, main_path_abs],
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            cwd=server_dir,
            text=True, encoding='utf-8', errors='replace',
            bufsize=1, env=env, universal_newlines=True,
            creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == 'win32' else 0
        )
        
        log(f"[{ts()}] ✅ Server marked as running")
        log(f"[{ts()}] 📌 PID: {proc.pid}")
        if assigned_port:
            log(f"[{ts()}] 📍 Port: {assigned_port}")
        log("")
        
        def rate_monitor():
            while proc.poll() is None:
                time.sleep(5)
                exceeded, avg_cpu = rate_limiter.check_rate(server_id, cpu_limit)
                if exceeded:
                    log(f"[{datetime.now().strftime('%I:%M:%S %p')}] ⚠️ CPU Limit! {avg_cpu:.1f}% > {cpu_limit}%")
                    proc.terminate()
                    time.sleep(2)
                    if proc.poll() is None:
                        proc.kill()
                    
                    users = load_users()
                    for uname, data in users.items():
                        if uname == 'admin': continue
                        servers = data.get('servers', [])
                        if not isinstance(servers, list): continue
                        for s in servers:
                            if isinstance(s, dict) and s.get('server_id') == server_id:
                                s['status'] = 'stopped'
                                s['pid'] = None
                                s['rate_limit_exceeded'] = True
                                s['stopped_by_user'] = False
                                save_users(users)
                                break
                    break
        
        threading.Thread(target=rate_monitor, daemon=True).start()
        
        def stream_output():
            try:
                with open(log_file, 'a', encoding='utf-8') as f:
                    for line in iter(proc.stdout.readline, ''):
                        if line:
                            line = line.rstrip('\n\r')
                            if line:
                                f.write(f"[{datetime.now().strftime('%I:%M:%S %p')}] {line}\n")
                                f.flush()
            except:
                pass
        
        threading.Thread(target=stream_output, daemon=True).start()
        
        return proc.pid, None
        
    except Exception as e:
        log(f"[{ts()}] ❌ Error: {str(e)}")
        return None, str(e)

def stop_bot_process(pid):
    try:
        if sys.platform == 'win32':
            subprocess.run(['taskkill', '/F', '/PID', str(pid)], capture_output=True)
        else:
            os.kill(pid, 15)
        return True
    except:
        return False

def monitor_bot(server_id, pid):
    while True:
        try:
            if sys.platform == 'win32':
                result = subprocess.run(['tasklist', '/FI', f'PID eq {pid}'], capture_output=True, text=True)
                if str(pid) not in result.stdout:
                    break
            else:
                try:
                    os.kill(pid, 0)
                except:
                    break
        except:
            break
        time.sleep(5)
    
    server, _ = get_server_by_id(server_id)
    if not server:
        return
    
    valid, _ = check_expiry(server_id)
    if not valid:
        if server.get('pid'):
            stop_bot_process(server['pid'])
        server['status'] = 'stopped'
        server['pid'] = None
        users = load_users()
        for uname, data in users.items():
            if uname == 'admin': continue
            for s in data.get('servers', []):
                if s.get('server_id') == server_id:
                    s['status'] = 'stopped'
                    s['pid'] = None
                    break
        save_users(users)
        return
    
    if server.get('stopped_by_user'):
        return
    if server.get('rate_limit_exceeded'):
        return
    
    if should_auto_restart(server_id):
        time.sleep(3)
        new_pid, error = run_bot(server_id, server.get('main_file', 'main.py'), 
                                 server.get('requirements_file', 'requirements.txt'))
        if new_pid:
            users = load_users()
            for uname, data in users.items():
                if uname == 'admin': continue
                servers = data.get('servers', [])
                if not isinstance(servers, list): continue
                for s in servers:
                    if isinstance(s, dict) and s.get('server_id') == server_id:
                        s['status'] = 'running'
                        s['pid'] = new_pid
                        s['started_at'] = str(datetime.now())
                        s['rate_limit_exceeded'] = False
                        s['stopped_by_user'] = False
                        save_users(users)
                        break
            threading.Thread(target=monitor_bot, args=(server_id, new_pid), daemon=True).start()
    else:
        users = load_users()
        for uname, data in users.items():
            if uname == 'admin': continue
            servers = data.get('servers', [])
            if not isinstance(servers, list): continue
            for s in servers:
                if isinstance(s, dict) and s.get('server_id') == server_id:
                    s['status'] = 'stopped'
                    s['pid'] = None
                    save_users(users)
                    return

def get_process_stats(pid):
    try:
        proc = psutil.Process(pid)
        cpu = proc.cpu_percent(interval=0.5)
        mem = proc.memory_info()
        ram = mem.rss / (1024 * 1024)
        return {
            'cpu_percent': round(cpu, 1),
            'ram_mb': round(ram, 1),
            'ram_display': f"{ram:.1f} MB" if ram < 1024 else f"{ram/1024:.1f} GB",
        }
    except:
        return {'cpu_percent': 0, 'ram_mb': 0, 'ram_display': '0 MB'}

def get_network_stats(psutil_pid):
    try:
        proc = psutil.Process(psutil_pid)
        io = proc.io_counters()
        if io:
            read_kb = io.read_bytes / 1024
            write_kb = io.write_bytes / 1024
            return format_bytes(read_kb), format_bytes(write_kb)
    except:
        pass
    return "0 KB", "0 KB"

def format_bytes(kb):
    if kb < 1024:
        return f"{kb:.1f} KB"
    mb = kb / 1024
    if mb < 1024:
        return f"{mb:.1f} MB"
    gb = mb / 1024
    return f"{gb:.2f} GB"

# ============================================
# PUBLIC API
# ============================================
@app.route('/api/create', methods=['GET'])
def api_create_server():
    username = request.args.get('username', '').strip()
    password = request.args.get('password', '').strip()
    server_type = request.args.get('type', 'python').strip()
    ram = request.args.get('ram', '1GB').strip()
    disk = request.args.get('disk', '1GB').strip()
    cpu_limit = int(request.args.get('cpu', '30'))
    days = int(request.args.get('days', '3'))
    
    valid, msg = validate_username(username)
    if not valid:
        return jsonify({'status': 'error', 'message': msg}), 400
    
    if not password:
        password = generate_random_password(12)
    elif len(password) < 8:
        return jsonify({'status': 'error', 'message': 'Password must be at least 8 characters!'}), 400
    
    if cpu_limit < 10 or cpu_limit > 100:
        return jsonify({'status': 'error', 'message': 'CPU limit must be between 10 and 100!'}), 400
    
    if days < 1 or days > 365:
        return jsonify({'status': 'error', 'message': 'Days must be between 1 and 365!'}), 400
    
    users = load_users()
    
    if username in users:
        return jsonify({'status': 'error', 'message': f"Username '{username}' already exists!"}), 400
    
    server_id = secrets.token_hex(4).upper()
    expiry_date = datetime.now() + timedelta(days=days)
    
    create_default_files(get_server_dir(server_id))
    
    host = request.host
    is_local = host.startswith('localhost') or host.startswith('127.0.0.1') or host.startswith('192.168')
    scheme = 'http' if is_local else 'https'
    full_url = f"{scheme}://{host}/{server_id}/login"
    
    assigned_port, port_error = assign_port(server_id)
    if port_error:
        return jsonify({'status': 'error', 'message': port_error}), 400
    
    assigned_node = assign_server_to_node(server_id)
    
    new_server = {
        'server_id': server_id,
        'login_url': f"/{server_id}/login",
        'dashboard_url': f"/{server_id}/home",
        'full_link': full_url,
        'type': server_type,
        'ram': ram,
        'disk': disk,
        'status': 'stopped',
        'pid': None,
        'port': assigned_port,
        'created': str(datetime.now()),
        'expiry': str(expiry_date),
        'main_file': 'main.py',
        'requirements_file': 'requirements.txt',
        'cpu_limit': cpu_limit,
        'rate_limit_exceeded': False,
        'stopped_by_user': False,
        'node': assigned_node
    }
    
    users[username] = {
        'password': password,
        'role': 'user',
        'servers': [new_server],
        'created_at': str(datetime.now()),
        'total_spent': 0
    }
    save_users(users)
    
    audit_log('API_SERVER_CREATE', username, f"Server: {server_id}, Node: {assigned_node}")
    
    return jsonify({
        'status': 'success',
        'message': 'Panel created successfully!',
        'username': username,
        'password': password,
        'server_type': server_type,
        'ram': ram,
        'disk': disk,
        'cpu_limit': cpu_limit,
        'validity': f'{days} days',
        'expiry_date': expiry_date.strftime('%Y-%m-%d'),
        'full_url': full_url,
        'server_id': server_id,
        'port': assigned_port,
        'node': assigned_node
    }), 200

# ============================================
# ROUTES
# ============================================
@app.route('/')
def index():
    if 'user' in session and session.get('role') == 'user':
        return redirect(url_for('user_dashboard'))
    elif 'user' in session and session.get('role') == 'admin':
        return redirect(url_for('admin_dashboard'))
    else:
        return render_template('landing.html')

@app.route('/health')
def health_check():
    return jsonify({
        'status': 'healthy',
        'timestamp': str(datetime.now()),
        'version': '2.0.0',
        'servers': len(os.listdir(BOTS_DIR)) if os.path.exists(BOTS_DIR) else 0
    })

@app.route('/pricing')
def pricing_page():
    packages = load_yuta_packages()
    settings = load_yuta_settings()
    return render_template('pricing.html', packages=packages, settings=settings)

@app.route('/checkout/<package_id>')
def checkout_page(package_id):
    packages = load_yuta_packages()
    package = packages.get(package_id)
    if not package:
        return redirect(url_for('pricing_page'))
    settings = load_yuta_settings()
    return render_template('checkout.html', package=package, settings=settings)

# ============================================
# SIGN IN / SIGN UP
# ============================================
@app.route('/signin')
def signin_page():
    if 'user' in session and session.get('role') == 'user':
        return redirect(url_for('user_dashboard'))
    return render_template('signin.html')

@app.route('/signup')
def signup_page():
    return render_template('signup.html')

# ============================================
# ADMIN LOGIN - FIXED
# ============================================

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username', '')
        password = request.form.get('password', '')
        users = load_users()
        
        # Debug: Print for checking
        print(f"[LOGIN] Username: {username}, Password: {password}")
        print(f"[LOGIN] Admin stored: {users.get('admin', {}).get('password', '')}")
        
        if username == 'admin':
            # Plain text password check (since we removed hashing)
            if password == users.get('admin', {}).get('password', ''):
                session.permanent = True
                session['user'] = 'admin'
                session['role'] = 'admin'
                session['_permanent'] = True
                audit_log('ADMIN_LOGIN', 'admin', f"IP: {request.remote_addr}")
                return redirect(url_for('admin_dashboard'))
            else:
                print(f"[LOGIN] Admin password mismatch")
        return render_template('login.html', error="Invalid credentials!")
    return render_template('login.html', error=None)

# ============================================
# USER ACCOUNT API (ADD THIS SECTION)
# ============================================

@app.route('/api/user/account/password')
@login_required
def api_get_account_password():
    """Get logged in user's account password"""
    if 'user' not in session or session.get('role') != 'user':
        return jsonify({'status': 'error', 'message': 'Not logged in'}), 401
    
    username = session['user']
    users = load_users()
    user_data = users.get(username, {})
    
    return jsonify({
        'status': 'success',
        'password': user_data.get('password', ''),
        'username': username
    })

@app.route('/api/user/account/delete', methods=['POST'])
@login_required
def api_delete_account():
    """Delete user account"""
    if 'user' not in session:
        return jsonify({'status': 'error', 'message': 'Not logged in'}), 401
    
    username = session['user']
    if username == 'admin':
        return jsonify({'status': 'error', 'message': 'Cannot delete admin account!'}), 400
    
    users = load_users()
    if username in users:
        # Delete all servers
        for server in users[username].get('servers', []):
            server_id = server.get('server_id')
            if server_id:
                try:
                    shutil.rmtree(get_server_dir(server_id))
                except:
                    pass
                remove_port_assignment(server_id)
        
        del users[username]
        save_users(users)
        session.clear()
        audit_log('ACCOUNT_DELETED', username, "User deleted own account")
        
        return jsonify({'status': 'success', 'message': 'Account deleted successfully!'})
    
    return jsonify({'status': 'error', 'message': 'User not found!'}), 404

@app.route('/api/user/account/update', methods=['POST'])
@login_required
def api_update_account():
    """Update user account info"""
    if 'user' not in session:
        return jsonify({'status': 'error', 'message': 'Not logged in'}), 401
    
    username = session['user']
    data = request.get_json()
    email = data.get('email', '').strip()
    
    if email:
        valid, msg = validate_email(email)
        if not valid:
            return jsonify({'status': 'error', 'message': msg}), 400
    
    users = load_users()
    if username in users:
        if email:
            users[username]['email'] = email
        save_users(users)
        audit_log('ACCOUNT_UPDATED', username, f"Email: {email}")
        return jsonify({'status': 'success', 'message': 'Account updated!'})
    
    return jsonify({'status': 'error', 'message': 'User not found!'}), 404

@app.route('/<server_id>/login', methods=['GET', 'POST'])
def server_login(server_id):
    valid, result = check_server_valid(server_id)
    if not valid:
        return render_template('error.html', error_type=result if result else "deleted", server_link=server_id)
    
    if request.method == 'POST':
        username = request.form.get('username', '')
        password = request.form.get('password', '')
        users = load_users()
        
        for uname, data in users.items():
            if uname == 'admin': continue
            servers = data.get('servers', [])
            if not isinstance(servers, list): continue
            for s in servers:
                if isinstance(s, dict) and s.get('server_id') == server_id:
                    if username == uname and data.get('password') == password:
                        session.permanent = True
                        session['user'] = uname
                        session['role'] = 'user'
                        session['current_server_id'] = server_id
                        session['_permanent'] = True
                        audit_log('SERVER_LOGIN', uname, f"Server: {server_id}")
                        return redirect(url_for('server_home', server_id=server_id))
                    else:
                        return render_template('login.html', error="Invalid credentials!")
        return render_template('login.html', error="Invalid login!")
    return render_template('login.html', error=None)

@app.route('/<server_id>/home')
def server_home(server_id):
    if 'user' not in session or session.get('role') != 'user':
        return redirect(url_for('server_login', server_id=server_id))
    if session.get('current_server_id') != server_id:
        session.clear()
        return redirect(url_for('server_login', server_id=server_id))
    
    valid, result = check_server_valid(server_id)
    if not valid:
        session.clear()
        return render_template('error.html', error_type=result if result else "deleted", server_link=server_id)
    
    return render_template('home.html', username=session['user'], current_server=result)

@app.route('/logout')
def logout():
    username = session.get('user', 'Unknown')
    audit_log('LOGOUT', username, f"IP: {request.remote_addr}")
    session.clear()
    response = redirect(url_for('signin_page'))
    response.set_cookie('session', '', expires=0, path='/')
    response.delete_cookie('session', path='/')
    return response

# ============================================
# USER ACCOUNT SYSTEM
# ============================================
@app.route('/user/register', methods=['POST'])
def user_register():
    data = request.get_json()
    username = data.get('username', '').strip()
    password = data.get('password', '').strip()
    email = data.get('email', '').strip()
    
    print(f"[REGISTER] Username: {username}, Password: {password}, Email: {email}")  # Debug
    
    # Validate username
    if not username or len(username) < 3:
        return jsonify({'status': 'error', 'message': 'Username must be at least 3 characters'}), 400
    
    if not re.match(r'^[a-zA-Z0-9_]+$', username):
        return jsonify({'status': 'error', 'message': 'Username can only contain letters, numbers and underscores'}), 400
    
    # Validate password
    if not password or len(password) < 8:
        return jsonify({'status': 'error', 'message': 'Password must be at least 8 characters'}), 400
    
    if not re.search(r'[A-Z]', password):
        return jsonify({'status': 'error', 'message': 'Password must contain at least one uppercase letter'}), 400
    
    if not re.search(r'[a-z]', password):
        return jsonify({'status': 'error', 'message': 'Password must contain at least one lowercase letter'}), 400
    
    if not re.search(r'[0-9]', password):
        return jsonify({'status': 'error', 'message': 'Password must contain at least one number'}), 400
    
    # Validate email (optional)
    if email:
        pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        if not re.match(pattern, email):
            return jsonify({'status': 'error', 'message': 'Invalid email format'}), 400
    
    users = load_users()
    
    # Check if username already exists
    if username in users:
        return jsonify({'status': 'error', 'message': 'Username already exists!'}), 400
    
    # CRITICAL: Store the password they provided
    users[username] = {
        'password': password,  # Plain text (as requested)
        'role': 'user',
        'email': email,
        'servers': [],
        'created_at': str(datetime.now()),
        'total_spent': 0
    }
    
    # Debug: Print what's being saved
    print(f"[REGISTER] Saving user: {username} with password: {password}")
    
    save_users(users)
    
    # Verify it was saved correctly
    saved_user = load_users().get(username, {})
    print(f"[REGISTER] Saved password: {saved_user.get('password', 'NOT FOUND')}")
    
    audit_log('USER_REGISTER', username, f"Email: {email}, IP: {request.remote_addr}")
    
    return jsonify({
        'status': 'success',
        'message': 'Account created successfully!',
        'username': username
    })

@app.route('/user/login', methods=['POST'])
def user_login():
    data = request.get_json()
    username = data.get('username', '').strip()
    password = data.get('password', '').strip()
    remember_me = data.get('remember_me', True)
    
    client_ip = request.remote_addr
    
    # Rate limit for failed logins
    if client_ip in FAILED_LOGIN_ATTEMPTS:
        attempts, last_time = FAILED_LOGIN_ATTEMPTS[client_ip]
        if attempts >= 5 and time.time() - last_time < 300:
            return jsonify({'status': 'error', 'message': 'Too many failed attempts. Try again later!'}), 429
    
    users = load_users()
    
    # Check if user exists and password matches
    if username in users:
        stored_password = users[username].get('password', '')
        
        # Debug: Print for checking
        print(f"[USER_LOGIN] Username: {username}")
        print(f"[USER_LOGIN] Provided: {password}")
        print(f"[USER_LOGIN] Stored: {stored_password}")
        
        if password == stored_password:
            if users[username].get('role') == 'admin':
                return jsonify({'status': 'error', 'message': 'Please use admin login!'}), 400
            
            # Clear failed attempts
            FAILED_LOGIN_ATTEMPTS.pop(client_ip, None)
            
            session.permanent = True
            session['user'] = username
            session['role'] = 'user'
            session['user_logged_in'] = True
            session['_permanent'] = True
            
            if remember_me:
                session.permanent = True
                app.permanent_session_lifetime = timedelta(days=30)
            else:
                session.permanent = False
            
            audit_log('USER_LOGIN', username, f"IP: {client_ip}")
            
            return jsonify({
                'status': 'success',
                'message': 'Login successful!',
                'username': username,
                'redirect': '/user/dashboard'
            })
    
    # Track failed attempts
    if client_ip in FAILED_LOGIN_ATTEMPTS:
        attempts, _ = FAILED_LOGIN_ATTEMPTS[client_ip]
        FAILED_LOGIN_ATTEMPTS[client_ip] = (attempts + 1, time.time())
    else:
        FAILED_LOGIN_ATTEMPTS[client_ip] = (1, time.time())
    
    return jsonify({'status': 'error', 'message': 'Invalid credentials!'}), 401

@app.route('/user/dashboard')
@login_required
def user_dashboard():
    username = session['user']
    session.permanent = True
    session.modified = True
    
    users = load_users()
    user_data = users.get(username, {})
    servers = user_data.get('servers', [])
    
    packages = load_yuta_packages()
    invoices = load_yuta_invoices()
    user_invoices = [inv for inv in invoices if inv.get('username') == username]
    
    return render_template('user_dashboard.html',
                         username=username, user_data=user_data,
                         servers=servers, packages=packages, invoices=user_invoices)

@app.route('/user/dashboard/data')
@login_required
def user_dashboard_data():
    username = session['user']
    users = load_users()
    user_data = users.get(username, {})
    servers = user_data.get('servers', [])
    
    invoices = load_yuta_invoices()
    user_invoices = [inv for inv in invoices if inv.get('username') == username]
    
    return jsonify({
        'status': 'success',
        'username': username,
        'servers': servers,
        'invoices': user_invoices
    })

# ============================================
# PORT API
# ============================================
@app.route('/api/ports/available')
@login_required
def api_available_ports():
    used_ports = set(PORT_ALLOCATIONS.keys())
    for conn in psutil.net_connections():
        if conn.laddr.port in range(5001, 6001):
            used_ports.add(conn.laddr.port)
    
    available = [p for p in range(5001, 6001) if p not in used_ports]
    return jsonify({
        'status': 'success',
        'available_count': len(available),
        'used_count': len(used_ports),
        'available_ports': available[:20]
    })

@app.route('/api/port/assign/<server_id>', methods=['POST'])
@login_required
def api_assign_port(server_id):
    data = request.get_json()
    requested_port = data.get('port', None)
    
    port, error = assign_port(server_id, requested_port)
    if error:
        return jsonify({'status': 'error', 'message': error}), 400
    
    users = load_users()
    for uname, udata in users.items():
        if uname == 'admin': continue
        for s in udata.get('servers', []):
            if s.get('server_id') == server_id:
                s['port'] = port
                save_users(users)
                break
    
    audit_log('PORT_ASSIGN_USER', session['user'], f"Server: {server_id}, Port: {port}")
    
    return jsonify({'status': 'success', 'message': f'Port {port} assigned!', 'port': port})

@app.route('/api/port/release/<server_id>', methods=['POST'])
@login_required
def api_release_port(server_id):
    port = remove_port_assignment(server_id)
    if port:
        users = load_users()
        for uname, udata in users.items():
            if uname == 'admin': continue
            for s in udata.get('servers', []):
                if s.get('server_id') == server_id:
                    s['port'] = None
                    save_users(users)
                    break
        
        audit_log('PORT_RELEASE_USER', session['user'], f"Server: {server_id}, Port: {port}")
        return jsonify({'status': 'success', 'message': f'Port {port} released!'})
    
    return jsonify({'status': 'error', 'message': 'No port assigned!'}), 404

# ============================================
# PAYMENT API
# ============================================
@app.route('/api/payment/create', methods=['POST'])
def api_create_payment():
    data = request.get_json()
    
    package_id = data.get('package_id', '')
    username = data.get('username', '')
    email = data.get('email', '')
    
    packages = load_yuta_packages()
    package = packages.get(package_id)
    
    if not package:
        return jsonify({'status': 'error', 'message': 'Package not found!'}), 400
    
    if not package.get('active', True):
        return jsonify({'status': 'error', 'message': 'Package is not active!'}), 400
    
    if package.get('is_free'):
        settings = load_yuta_settings()
        if settings.get('allow_free_only_once', True):
            free_trials = load_yuta_free_trials()
            if username in free_trials:
                return jsonify({'status': 'error', 'message': 'You already used your free trial!'}), 400
            
            free_trials[username] = {
                'used_at': str(datetime.now()),
                'package': package_id,
                'ip': request.remote_addr
            }
            save_yuta_free_trials(free_trials)
        
        password = data.get('password', generate_random_password(12))
        result, error = create_server_from_package(username, password, package_id)
        
        if result:
            audit_log('FREE_SERVER_CREATE', username, f"Server: {result['server_id']}")
            return jsonify({
                'status': 'success',
                'message': 'Free server created!',
                'server_id': result['server_id'],
                'login_url': result['login_url'],
                'username': username,
                'password': password,
                'port': result.get('port')
            })
        else:
            return jsonify({'status': 'error', 'message': error}), 400
    
    settings = load_yuta_settings()
    bohudur.set_api_key(settings.get('bohudur_api_key', ''))
    
    if not settings.get('bohudur_api_key'):
        return jsonify({'status': 'error', 'message': 'Payment gateway not configured!'}), 400
    
    invoice_id = f"YUTA-{secrets.token_hex(4).upper()}"
    amount = package['price']
    
    host = request.host_url.rstrip('/')
    
    result = bohudur.create_payment(
        full_name=username, email=email or f"{username}@yutahost.com",
        amount=amount, order_id=invoice_id, user_id=username,
        redirect_url=f"{host}/payment/success", cancel_url=f"{host}/payment/cancel",
        webhook_url=f"{host}/api/payment/webhook/success",
        metadata={'package_id': package_id}
    )
    
    if result['success']:
        transaction_id = result.get('transaction_id', '')
        invoices = load_yuta_invoices()
        invoices.append({
            'invoice_id': invoice_id,
            'transaction_id': transaction_id,
            'username': username,
            'email': email,
            'package_id': package_id,
            'amount': amount,
            'status': 'pending',
            'created_at': str(datetime.now()),
            'paid_at': None,
            'server_created': False
        })
        save_yuta_invoices(invoices)
        
        return jsonify({
            'status': 'success',
            'payment_url': result['payment_url'],
            'invoice_id': invoice_id,
            'transaction_id': transaction_id,
            'amount': amount
        })
    else:
        return jsonify({'status': 'error', 'message': result.get('error', 'Payment creation failed!')}), 400

@app.route('/api/payment/webhook/success', methods=['POST', 'GET'])
def payment_webhook():
    if request.method == 'POST':
        data = request.get_json(silent=True) or {}
    else:
        data = request.args.to_dict()
    
    transaction_id = data.get('transaction_id', '')
    
    if transaction_id:
        invoices = load_yuta_invoices()
        for inv in invoices:
            if inv.get('transaction_id') == transaction_id and inv['status'] == 'pending':
                inv['status'] = 'paid'
                inv['paid_at'] = str(datetime.now())
                
                password = generate_random_password(12)
                result, error = create_server_from_package(inv['username'], password, inv['package_id'])
                
                if result:
                    inv['server_created'] = True
                    inv['server_id'] = result['server_id']
                
                save_yuta_invoices(invoices)
                
                users = load_users()
                if inv['username'] in users:
                    users[inv['username']]['total_spent'] = users[inv['username']].get('total_spent', 0) + inv['amount']
                    if 'email' not in users[inv['username']] or not users[inv['username']].get('email'):
                        users[inv['username']]['email'] = inv.get('email', '')
                    save_users(users)
                
                audit_log('PAYMENT_WEBHOOK', inv['username'], f"Amount: {inv['amount']}, Server: {result.get('server_id')}")
                
                return jsonify({'status': 'success', 'message': 'Payment processed and server created!'})
    
    return jsonify({'status': 'ignored'})

# ============================================
# PAYMENT SUCCESS/CANCEL
# ============================================
@app.route('/payment/success')
def payment_success():
    paymentkey = request.args.get('paymentkey', '')
    
    if paymentkey:
        invoices = load_yuta_invoices()
        
        for inv in invoices:
            if inv.get('transaction_id') == paymentkey:
                if inv['status'] == 'pending':
                    inv['status'] = 'paid'
                    inv['paid_at'] = str(datetime.now())
                    
                    password = generate_random_password(12)
                    result, error = create_server_from_package(inv['username'], password, inv['package_id'])
                    
                    if result:
                        inv['server_created'] = True
                        inv['server_id'] = result['server_id']
                        save_yuta_invoices(invoices)
                        
                        users = load_users()
                        if inv['username'] in users:
                            users[inv['username']]['total_spent'] = users[inv['username']].get('total_spent', 0) + inv['amount']
                            if not users[inv['username']].get('email'):
                                users[inv['username']]['email'] = inv.get('email', '')
                            save_users(users)
                        
                        packages = load_yuta_packages()
                        pkg = packages.get(inv['package_id'], {})
                        
                        audit_log('PAYMENT_SUCCESS', inv['username'], f"Server: {result['server_id']}, Amount: {inv['amount']}")
                        
                        return render_template('payment_success.html',
                            invoice_id=inv['invoice_id'], transaction_id=paymentkey,
                            username=inv['username'], server_id=result['server_id'],
                            package_name=pkg.get('name', inv['package_id']),
                            amount=inv['amount'], ram=pkg.get('ram', 'N/A'),
                            disk=pkg.get('disk', 'N/A'), days=pkg.get('days', 30),
                            port=result.get('port')
                        )
                    else:
                        save_yuta_invoices(invoices)
                        return render_template('payment_success.html', error=f"Server creation failed: {error}")
                
                elif inv['status'] == 'paid':
                    return render_template('payment_success.html',
                        invoice_id=inv['invoice_id'], transaction_id=paymentkey,
                        username=inv['username'], server_id=inv.get('server_id', ''),
                        package_name=inv['package_id'], amount=inv['amount'], already_paid=True
                    )
    
    return render_template('payment_success.html')

@app.route('/payment/cancel')
def payment_cancel():
    paymentkey = request.args.get('paymentkey', '')
    if paymentkey:
        invoices = load_yuta_invoices()
        for inv in invoices:
            if inv.get('transaction_id') == paymentkey and inv['status'] == 'pending':
                inv['status'] = 'cancelled'
                inv['cancelled_at'] = str(datetime.now())
                save_yuta_invoices(invoices)
                audit_log('PAYMENT_CANCEL', inv.get('username', 'Unknown'), f"Transaction: {paymentkey}")
                break
    
    return render_template('payment_cancel.html')

# ============================================
# ADMIN PANEL
# ============================================
@app.route('/admin')
@login_required
@admin_required
def admin_dashboard():
    users = load_users()
    user_list = []
    total_servers = 0
    total_running = 0
    expired_count = 0
    
    for uname, data in users.items():
        if uname == 'admin': continue
        servers = data.get('servers', [])
        if not isinstance(servers, list):
            servers = []
        
        running = sum(1 for s in servers if isinstance(s, dict) and s.get('status') == 'running')
        expired = sum(1 for s in servers if isinstance(s, dict) and s.get('expiry', '') and 
                     datetime.now() > datetime.strptime(s.get('expiry'), '%Y-%m-%d %H:%M:%S.%f'))
        
        total_servers += len(servers)
        total_running += running
        expired_count += expired
        
        user_list.append({
            'username': uname,
            'password': data.get('password', ''),
            'servers': servers,
            'server_count': len(servers),
            'running_count': running,
            'expired_count': expired
        })
    
    nodes_data = load_nodes()
    total_nodes = len(nodes_data['nodes'])
    online_nodes = sum(1 for n in nodes_data['nodes'].values() if n.get('status') == 'online')
    
    return render_template('admin.html',
                         users=user_list,
                         total_servers=total_servers,
                         total_running=total_running,
                         expired_count=expired_count,
                         total_nodes=total_nodes,
                         online_nodes=online_nodes,
                         current_time=datetime.now())

# ============================================
# ADMIN PACKAGE MANAGEMENT
# ============================================
@app.route('/admin/packages')
@login_required
@admin_required
def admin_packages_page():
    packages = load_yuta_packages()
    settings = load_yuta_settings()
    invoices = load_yuta_invoices()
    free_trials = load_yuta_free_trials()
    
    total_revenue = sum(inv['amount'] for inv in invoices if inv['status'] == 'paid')
    total_orders = len(invoices)
    paid_orders = len([inv for inv in invoices if inv['status'] == 'paid'])
    pending_orders = len([inv for inv in invoices if inv['status'] == 'pending'])
    total_free_used = len(free_trials)
    
    stats = {
        'total_revenue': total_revenue,
        'total_orders': total_orders,
        'paid_orders': paid_orders,
        'pending_orders': pending_orders,
        'total_free_used': total_free_used
    }
    
    return render_template('admin_packages.html',
                         packages=packages, settings=settings,
                         invoices=invoices[-50:], stats=stats)

@app.route('/api/packages/list')
def public_get_packages():
    packages = load_yuta_packages()
    active_packages = {}
    for pkg_id, pkg in packages.items():
        if pkg.get('active', True):
            active_packages[pkg_id] = pkg
    return jsonify({'packages': active_packages})

@app.route('/admin/api/packages/list')
@login_required
@admin_required
def admin_get_packages():
    packages = load_yuta_packages()
    return jsonify({'packages': packages})

@app.route('/admin/api/packages/get/<package_id>')
@login_required
@admin_required
def admin_get_single_package(package_id):
    packages = load_yuta_packages()
    pkg = packages.get(package_id)
    if not pkg:
        return jsonify({'error': 'Package not found'}), 404
    return jsonify({'success': True, 'package': pkg})

@app.route('/admin/api/packages/create', methods=['POST'])
@login_required
@admin_required
def admin_create_package():
    data = request.get_json()
    package_id = data.get('id', '').strip().lower()
    
    if not package_id or not re.match(r'^[a-zA-Z0-9_]+$', package_id):
        return jsonify({'error': 'Invalid package ID!'}), 400
    
    if package_id in ['free_trial']:
        return jsonify({'error': 'Cannot use reserved package ID!'}), 400
    
    packages = load_yuta_packages()
    if package_id in packages:
        return jsonify({'error': 'Package ID already exists!'}), 400
    
    price = int(data.get('price', 0))
    if price < 0:
        return jsonify({'error': 'Price cannot be negative!'}), 400
    
    packages[package_id] = {
        'id': package_id,
        'name': sanitize_input(data.get('name', package_id.title())),
        'icon': data.get('icon', '📦'),
        'price': price,
        'ram': data.get('ram', '1GB'),
        'disk': data.get('disk', '5GB'),
        'cpu_limit': int(data.get('cpu_limit', 80)),
        'days': int(data.get('days', 30)),
        'server_limit': int(data.get('server_limit', 5)),
        'active': data.get('active', True),
        'is_free': data.get('is_free', False),
        'features': data.get('features', [])
    }
    save_yuta_packages(packages)
    audit_log('PACKAGE_CREATE', session['user'], f"Package: {package_id}")
    
    return jsonify({'success': True, 'message': 'Package created!', 'package': packages[package_id]})

@app.route('/admin/api/packages/update/<package_id>', methods=['PUT'])
@login_required
@admin_required
def admin_update_package(package_id):
    data = request.get_json()
    packages = load_yuta_packages()
    if package_id not in packages:
        return jsonify({'error': 'Package not found!'}), 404
    
    pkg = packages[package_id]
    
    if 'name' in data:
        pkg['name'] = sanitize_input(data['name'])
    if 'icon' in data:
        pkg['icon'] = data['icon']
    if 'price' in data:
        price = int(data['price'])
        if price < 0:
            return jsonify({'error': 'Price cannot be negative!'}), 400
        pkg['price'] = price
    if 'ram' in data:
        pkg['ram'] = data['ram']
    if 'disk' in data:
        pkg['disk'] = data['disk']
    if 'cpu_limit' in data:
        pkg['cpu_limit'] = int(data['cpu_limit'])
    if 'days' in data:
        pkg['days'] = int(data['days'])
    if 'server_limit' in data:
        pkg['server_limit'] = int(data['server_limit'])
    if 'active' in data:
        pkg['active'] = data['active']
    if 'is_free' in data:
        pkg['is_free'] = data['is_free']
    if 'features' in data:
        pkg['features'] = data['features']
    
    save_yuta_packages(packages)
    audit_log('PACKAGE_UPDATE', session['user'], f"Package: {package_id}")
    
    return jsonify({'success': True, 'message': 'Package updated!', 'package': pkg})

@app.route('/admin/api/packages/delete/<package_id>', methods=['DELETE'])
@login_required
@admin_required
def admin_delete_package(package_id):
    if package_id == 'free_trial':
        return jsonify({'error': 'Cannot delete free trial package!'}), 400
    
    packages = load_yuta_packages()
    if package_id in packages:
        del packages[package_id]
        save_yuta_packages(packages)
        audit_log('PACKAGE_DELETE', session['user'], f"Package: {package_id}")
        return jsonify({'success': True, 'message': 'Package deleted!'})
    
    return jsonify({'error': 'Package not found!'}), 404

@app.route('/admin/api/packages/toggle/<package_id>', methods=['POST'])
@login_required
@admin_required
def admin_toggle_package(package_id):
    packages = load_yuta_packages()
    if package_id in packages:
        packages[package_id]['active'] = not packages[package_id].get('active', True)
        save_yuta_packages(packages)
        status = 'activated' if packages[package_id]['active'] else 'deactivated'
        audit_log('PACKAGE_TOGGLE', session['user'], f"Package: {package_id} -> {status}")
        return jsonify({'success': True, 'message': f'Package {status}!'})
    
    return jsonify({'error': 'Package not found!'}), 404

# ============================================
# ADMIN SETTINGS MANAGEMENT
# ============================================
@app.route('/admin/api/settings/get')
@login_required
@admin_required
def admin_get_settings():
    settings = load_yuta_settings()
    return jsonify({'settings': settings})

@app.route('/admin/api/settings/save', methods=['POST'])
@login_required
@admin_required
def admin_save_settings():
    data = request.get_json()
    settings = load_yuta_settings()
    
    updateable_keys = [
        'site_name', 'bohudur_api_key', 'auto_verify_payment',
        'currency', 'trial_days', 'trial_enabled', 'allow_free_only_once',
        'auto_delete_days'
    ]
    
    for key in updateable_keys:
        if key in data:
            if key in ['auto_verify_payment', 'trial_enabled', 'allow_free_only_once']:
                settings[key] = bool(data[key])
            elif key in ['trial_days', 'auto_delete_days']:
                value = int(data[key])
                if value < 1:
                    return jsonify({'error': f'{key} must be at least 1'}), 400
                settings[key] = value
            else:
                if key == 'site_name':
                    settings[key] = sanitize_input(data[key])
                else:
                    settings[key] = data[key]
    
    save_yuta_settings(settings)
    if 'bohudur_api_key' in data:
        bohudur.set_api_key(data['bohudur_api_key'])
    
    audit_log('SETTINGS_UPDATE', session['user'], "Settings updated")
    
    return jsonify({'success': True, 'message': 'Settings saved!'})

# ============================================
# ADMIN INVOICE MANAGEMENT
# ============================================
@app.route('/admin/api/invoices/list')
@login_required
@admin_required
def admin_get_invoices():
    invoices = load_yuta_invoices()
    status_filter = request.args.get('status', '')
    if status_filter:
        invoices = [inv for inv in invoices if inv.get('status') == status_filter]
    return jsonify({'invoices': invoices[-100:], 'total': len(invoices)})

@app.route('/admin/api/invoices/verify', methods=['POST'])
@login_required
@admin_required
def admin_verify_invoice():
    data = request.get_json()
    invoice_id = data.get('invoice_id', '')
    invoices = load_yuta_invoices()
    
    for inv in invoices:
        if inv['invoice_id'] == invoice_id and inv['status'] == 'pending':
            inv['status'] = 'paid'
            inv['paid_at'] = str(datetime.now())
            inv['verified_by'] = 'admin'
            
            password = generate_random_password(12)
            result, error = create_server_from_package(inv['username'], password, inv['package_id'])
            
            if result:
                inv['server_created'] = True
                inv['server_id'] = result['server_id']
                save_yuta_invoices(invoices)
                audit_log('INVOICE_VERIFY', session['user'], f"Invoice: {invoice_id}, Server: {result['server_id']}")
                return jsonify({'success': True, 'message': 'Verified!', 'server_id': result['server_id']})
            else:
                return jsonify({'error': error}), 400
    
    return jsonify({'error': 'Invoice not found!'}), 404

@app.route('/admin/api/invoices/reject/<invoice_id>', methods=['POST'])
@login_required
@admin_required
def admin_reject_invoice(invoice_id):
    invoices = load_yuta_invoices()
    for inv in invoices:
        if inv['invoice_id'] == invoice_id:
            inv['status'] = 'cancelled'
            inv['cancelled_at'] = str(datetime.now())
            inv['cancelled_by'] = 'admin'
            save_yuta_invoices(invoices)
            audit_log('INVOICE_REJECT', session['user'], f"Invoice: {invoice_id}")
            return jsonify({'success': True, 'message': 'Invoice rejected!'})
    
    return jsonify({'error': 'Invoice not found!'}), 404

# ============================================
# ADMIN SERVER MANAGEMENT
# ============================================
@app.route('/admin/api/server/resources/<server_id>', methods=['GET'])
@login_required
@admin_required
def admin_get_server_resources(server_id):
    users = load_users()
    for uname, udata in users.items():
        if uname == 'admin': continue
        for s in udata.get('servers', []):
            if s.get('server_id') == server_id:
                return jsonify({'success': True, 'server': {
                    'server_id': server_id,
                    'username': uname,
                    'ram': s.get('ram', '512MB'),
                    'disk': s.get('disk', '1GB'),
                    'cpu_limit': s.get('cpu_limit', 80),
                    'status': s.get('status', 'stopped'),
                    'expiry': s.get('expiry', ''),
                    'package': s.get('package', ''),
                    'created': s.get('created', ''),
                    'type': s.get('type', 'python'),
                    'port': s.get('port', get_server_port(server_id)),
                    'node': s.get('node', 'unknown')
                }})
    return jsonify({'error': 'Server not found'}), 404

@app.route('/admin/api/server/resources/update/<server_id>', methods=['POST'])
@login_required
@admin_required
def admin_update_server_resources(server_id):
    data = request.get_json()
    users = load_users()
    
    for uname, udata in users.items():
        if uname == 'admin': continue
        for s in udata.get('servers', []):
            if s.get('server_id') == server_id:
                if 'ram' in data:
                    s['ram'] = data['ram']
                if 'disk' in data:
                    s['disk'] = data['disk']
                if 'cpu_limit' in data:
                    cpu = int(data['cpu_limit'])
                    if cpu < 10 or cpu > 100:
                        return jsonify({'error': 'CPU limit must be between 10 and 100'}), 400
                    s['cpu_limit'] = cpu
                if 'port' in data:
                    new_port = int(data['port'])
                    assigned_port, error = assign_port(server_id, new_port)
                    if error:
                        return jsonify({'error': error}), 400
                    s['port'] = assigned_port
                if 'expiry_days' in data:
                    try:
                        current_expiry = datetime.strptime(s.get('expiry', str(datetime.now())), '%Y-%m-%d %H:%M:%S.%f')
                    except:
                        current_expiry = datetime.now()
                    new_expiry = current_expiry + timedelta(days=int(data['expiry_days']))
                    s['expiry'] = str(new_expiry)
                if 'package' in data:
                    s['package'] = data['package']
                if 'type' in data:
                    s['type'] = data['type']
                
                save_users(users)
                audit_log('SERVER_UPDATE', session['user'], f"Server: {server_id}")
                return jsonify({'success': True, 'message': 'Resources updated!'})
    
    return jsonify({'error': 'Server not found'}), 404

@app.route('/admin/api/server/resources/list')
@login_required
@admin_required
def admin_list_all_resources():
    users = load_users()
    all_servers = []
    
    for uname, udata in users.items():
        if uname == 'admin': continue
        for s in udata.get('servers', []):
            all_servers.append({
                'server_id': s.get('server_id', ''),
                'username': uname,
                'ram': s.get('ram', 'N/A'),
                'disk': s.get('disk', 'N/A'),
                'cpu_limit': s.get('cpu_limit', 80),
                'status': s.get('status', 'stopped'),
                'expiry': s.get('expiry', ''),
                'package': s.get('package', ''),
                'type': s.get('type', 'python'),
                'port': s.get('port', get_server_port(s.get('server_id', ''))),
                'node': s.get('node', 'unknown')
            })
    
    return jsonify({'success': True, 'servers': all_servers})

@app.route('/admin/api/server/resources/delete/<server_id>', methods=['POST'])
@login_required
@admin_required
def admin_delete_server_resource(server_id):
    users = load_users()
    
    for uname, udata in users.items():
        if uname == 'admin': continue
        servers = udata.get('servers', [])
        for s in servers:
            if s.get('server_id') == server_id:
                if s.get('pid'):
                    stop_bot_process(s['pid'])
                try:
                    shutil.rmtree(get_server_dir(server_id))
                except:
                    pass
                remove_port_assignment(server_id)
                udata['servers'] = [x for x in servers if x.get('server_id') != server_id]
                if len(udata['servers']) == 0:
                    del users[uname]
                save_users(users)
                audit_log('SERVER_DELETE', session['user'], f"Server: {server_id}, User: {uname}")
                return jsonify({'success': True, 'message': 'Server deleted!'})
    
    return jsonify({'error': 'Server not found'}), 404

@app.route('/admin/create_server', methods=['POST'])
@login_required
@admin_required
def create_server():
    data = request.get_json()
    username = data.get('username', '')
    password = data.get('password', '')
    server_type = data.get('server_type', 'python')
    ram = data.get('ram', '512MB')
    disk = data.get('disk', '1GB')
    expiry_days = int(data.get('expiry_days', 30))
    cpu_limit = int(data.get('cpu_limit', 80))
    requested_port = data.get('port', '')
    
    if not username or not password:
        return jsonify({'error': 'Username and password required!'}), 400
    
    valid, msg = validate_username(username)
    if not valid:
        return jsonify({'error': msg}), 400
    
    if len(password) < 8:
        return jsonify({'error': 'Password must be at least 8 characters!'}), 400
    
    users = load_users()
    server_id = secrets.token_hex(4).upper()
    expiry_date = datetime.now() + timedelta(days=expiry_days)
    create_default_files(get_server_dir(server_id))
    
    port_to_use = int(requested_port) if requested_port else None
    assigned_port, port_error = assign_port(server_id, port_to_use)
    if port_error:
        return jsonify({'error': port_error}), 400
    
    assigned_node = assign_server_to_node(server_id)
    
    new_server = {
        'server_id': server_id,
        'link': server_id,
        'login_url': f"/{server_id}/login",
        'dashboard_url': f"/{server_id}/home",
        'full_link': request.host_url.rstrip('/') + f"/{server_id}/home",
        'type': server_type,
        'ram': ram,
        'disk': disk,
        'status': 'stopped',
        'pid': None,
        'port': assigned_port,
        'created': str(datetime.now()),
        'expiry': str(expiry_date),
        'main_file': 'main.py',
        'requirements_file': 'requirements.txt',
        'cpu_limit': cpu_limit,
        'rate_limit_exceeded': False,
        'stopped_by_user': False,
        'node': assigned_node
    }
    
    if username not in users:
        users[username] = {
            'password': password,
            'role': 'user',
            'servers': [],
            'created_at': str(datetime.now()),
            'total_spent': 0
        }
    users[username]['servers'].append(new_server)
    save_users(users)
    
    audit_log('ADMIN_SERVER_CREATE', session['user'], f"User: {username}, Server: {server_id}")
    
    return jsonify({
        'success': True,
        'username': username,
        'password': password,
        'login_url': new_server['login_url'],
        'hostname': new_server['full_link'],
        'server_id': server_id,
        'port': assigned_port,
        'node': assigned_node
    })

@app.route('/admin/set_rate_limit/<server_id>', methods=['POST'])
@login_required
@admin_required
def set_rate_limit(server_id):
    cpu_limit = int(request.get_json().get('cpu_limit', 80))
    
    if cpu_limit < 10 or cpu_limit > 100:
        return jsonify({'error': 'CPU limit must be between 10 and 100'}), 400
    
    users = load_users()
    for uname, udata in users.items():
        if uname == 'admin': continue
        servers = udata.get('servers', [])
        if not isinstance(servers, list): continue
        for s in servers:
            if isinstance(s, dict) and s.get('server_id') == server_id:
                s['cpu_limit'] = cpu_limit
                save_users(users)
                audit_log('RATE_LIMIT_UPDATE', session['user'], f"Server: {server_id}, Limit: {cpu_limit}%")
                return jsonify({'success': True, 'cpu_limit': cpu_limit})
    
    return jsonify({'error': 'Not found'}), 404

@app.route('/admin/delete_server/<username>/<server_id>', methods=['POST'])
@login_required
@admin_required
def delete_server(username, server_id):
    users = load_users()
    if username in users:
        servers = users[username].get('servers', [])
        if not isinstance(servers, list):
            servers = []
        for s in servers:
            if isinstance(s, dict) and s.get('server_id') == server_id:
                if s.get('pid'):
                    stop_bot_process(s['pid'])
                try:
                    shutil.rmtree(get_server_dir(server_id))
                except:
                    pass
                remove_port_assignment(server_id)
                break
        users[username]['servers'] = [s for s in servers if isinstance(s, dict) and s.get('server_id') != server_id]
        if len(users[username]['servers']) == 0:
            del users[username]
        save_users(users)
        audit_log('ADMIN_SERVER_DELETE', session['user'], f"User: {username}, Server: {server_id}")
    
    return jsonify({'success': True})

# ============================================
# BOT API
# ============================================
@app.route('/api/run/<server_id>', methods=['POST'])
@login_required
@require_valid_server
def api_run(server_id):
    server, _ = get_server_by_id(server_id)
    if not server:
        return jsonify({'status': 'error', 'msg': 'Not found'})
    if server.get('status') == 'running':
        return jsonify({'status': 'error', 'msg': 'Already running!'})
    
    valid, _ = check_expiry(server_id)
    if not valid:
        return jsonify({'status': 'error', 'msg': 'Server expired!'}), 410
    
    server['rate_limit_exceeded'] = False
    server['stopped_by_user'] = False
    pid, error = run_bot(server_id, server.get('main_file', 'main.py'), server.get('requirements_file', 'requirements.txt'))
    
    if pid:
        users = load_users()
        for uname, data in users.items():
            if uname == 'admin': continue
            servers = data.get('servers', [])
            if not isinstance(servers, list): continue
            for s in servers:
                if isinstance(s, dict) and s.get('server_id') == server_id:
                    s['status'] = 'running'
                    s['pid'] = pid
                    s['started_at'] = str(datetime.now())
                    save_users(users)
                    break
        threading.Thread(target=monitor_bot, args=(server_id, pid), daemon=True).start()
        audit_log('BOT_START', session['user'], f"Server: {server_id}")
        return jsonify({'status': 'success', 'msg': 'Started!'})
    
    return jsonify({'status': 'error', 'msg': error or 'Failed'})

@app.route('/api/stop/<server_id>', methods=['POST'])
@login_required
@require_valid_server
def api_stop(server_id):
    server, _ = get_server_by_id(server_id)
    if not server:
        return jsonify({'status': 'error', 'msg': 'Not found'})
    if server.get('pid'):
        stop_bot_process(server['pid'])
    
    users = load_users()
    for uname, data in users.items():
        if uname == 'admin': continue
        servers = data.get('servers', [])
        if not isinstance(servers, list): continue
        for s in servers:
            if isinstance(s, dict) and s.get('server_id') == server_id:
                s['status'] = 'stopped'
                s['pid'] = None
                s['stopped_by_user'] = True
                save_users(users)
                break
    
    audit_log('BOT_STOP', session['user'], f"Server: {server_id}")
    return jsonify({'status': 'success', 'msg': 'Stopped'})

@app.route('/api/logs/<server_id>')
@login_required
@require_valid_server
def api_logs(server_id):
    log_file = os.path.join(get_server_dir(server_id), 'output.log')
    if os.path.exists(log_file):
        with open(log_file, 'r', encoding='utf-8') as f:
            logs = f.read()
    else:
        logs = ""
    return jsonify({'logs': logs})

@app.route('/api/clear_logs/<server_id>', methods=['POST'])
@login_required
@require_valid_server
def api_clear_logs(server_id):
    log_file = os.path.join(get_server_dir(server_id), 'output.log')
    try:
        if os.path.exists(log_file):
            try:
                os.remove(log_file)
            except:
                open(log_file, 'w').close()
        audit_log('LOGS_CLEAR', session['user'], f"Server: {server_id}")
        return jsonify({'status': 'success', 'msg': 'Cleared'})
    except:
        return jsonify({'status': 'error'}), 500

@app.route('/api/command', methods=['POST'])
@login_required
def api_command():
    data = request.get_json()
    cmd = data.get('cmd', '')
    server_id = data.get('server_id', '')
    
    dangerous_commands = ['rm -rf', 'sudo', 'chmod 777', 'dd if=', 'mkfs', 'format', 'del /f']
    for dangerous in dangerous_commands:
        if dangerous in cmd.lower():
            audit_log('COMMAND_BLOCKED', session['user'], f"Command: {cmd}")
            return jsonify({'status': 'error', 'msg': 'Command blocked for security'}), 403
    
    valid, _ = check_expiry(server_id)
    if not valid:
        return jsonify({'status': 'error', 'msg': 'Server expired!'}), 410
    
    log_file = os.path.join(get_server_dir(server_id), 'output.log')
    try:
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True,
                              cwd=get_server_dir(server_id), timeout=30,
                              creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == 'win32' else 0)
        output = (result.stdout + result.stderr)[:2000]
        with open(log_file, 'a', encoding='utf-8') as f:
            f.write(f"[{datetime.now().strftime('%I:%M:%S %p')}] $ {cmd}\n{output}\n")
        audit_log('COMMAND_EXEC', session['user'], f"Server: {server_id}, Command: {cmd[:50]}")
        return jsonify({'status': 'success', 'output': output})
    except subprocess.TimeoutExpired:
        return jsonify({'status': 'error', 'msg': 'Timeout'})
    except:
        return jsonify({'status': 'error', 'msg': 'Command failed'})

@app.route('/api/stats/<server_id>')
@login_required
@require_valid_server
def api_stats(server_id):
    server, _ = get_server_by_id(server_id)
    if not server:
        return jsonify({'cpu': '0%', 'ram': '0 MB', 'uptime': '0h', 'status': 'unknown',
                       'cpu_limit': 80, 'net_in': '0 KB', 'net_out': '0 KB', 'port': 0})
    
    uptime, cpu, ram, net_in, net_out = "0h 0m", "0%", "0 MB", "0 KB", "0 KB"
    
    if server.get('status') == 'running' and server.get('pid'):
        stats = get_process_stats(server['pid'])
        cpu = f"{stats['cpu_percent']}%"
        ram = stats['ram_display']
        net_in, net_out = get_network_stats(server['pid'])
    
    if server.get('status') == 'running' and server.get('started_at'):
        try:
            start = datetime.strptime(server['started_at'], '%Y-%m-%d %H:%M:%S.%f')
            diff = datetime.now() - start
            if diff.days > 0:
                uptime = f"{diff.days}d {diff.seconds//3600}h"
            else:
                h, m, s = diff.seconds // 3600, (diff.seconds % 3600) // 60, diff.seconds % 60
                uptime = f"{h}h {m}m {s}s"
        except:
            pass
    
    port = server.get('port', get_server_port(server_id))
    node = server.get('node', 'unknown')
    
    return jsonify({
        'cpu': cpu,
        'ram': ram,
        'uptime': uptime,
        'net_in': net_in,
        'net_out': net_out,
        'cpu_limit': server.get('cpu_limit', 80),
        'status': server.get('status', 'stopped'),
        'port': port,
        'node': node
    })

# ============================================
# PASSWORD CHANGE
# ============================================
@app.route('/api/change_password/<server_id>', methods=['POST'])
@login_required
def api_change_password(server_id):
    data = request.get_json()
    current_password = data.get('current_password', '')
    new_password = data.get('new_password', '')
    
    if not current_password or not new_password:
        return jsonify({'error': 'All fields are required!'}), 400
    
    valid, msg = validate_password(new_password)
    if not valid:
        return jsonify({'error': msg}), 400
    
    users = load_users()
    username = session.get('user')
    
    if username in users:
        if users[username].get('password') == current_password:
            users[username]['password'] = new_password
            save_users(users)
            audit_log('PASSWORD_CHANGE', username, f"Server: {server_id}")
            return jsonify({'success': True, 'msg': 'Password changed!'})
        return jsonify({'error': 'Current password is incorrect!'})
    
    return jsonify({'error': 'User not found!'}), 404

# ============================================
# GITHUB API
# ============================================
@app.route('/api/github/deploy/<server_id>', methods=['POST'])
@login_required
@require_valid_server
def api_github_deploy(server_id):
    data = request.get_json()
    repo_url = data.get('repo_url', '').strip()
    access_token = data.get('access_token', '').strip()
    is_private = data.get('is_private', False)
    
    if not repo_url:
        return jsonify({'status': 'error', 'msg': 'Repository URL is required!'}), 400
    
    if not repo_url.startswith('https://github.com/'):
        return jsonify({'status': 'error', 'msg': 'Invalid GitHub URL!'}), 400
    
    server_dir = get_server_dir(server_id)
    log_file = os.path.join(server_dir, 'github_deploy.log')
    
    try:
        with open(log_file, 'w', encoding='utf-8') as f:
            f.write(f"[{datetime.now().strftime('%I:%M:%S %p')}] Starting GitHub deployment...\n")
    except:
        pass
    
    def deploy_thread():
        try:
            import requests, shutil
            
            def deploy_log(msg):
                try:
                    with open(log_file, 'a', encoding='utf-8') as f:
                        f.write(f"[{datetime.now().strftime('%I:%M:%S %p')}] {msg}\n")
                except:
                    pass
            
            clean_url = repo_url.replace('.git', '').rstrip('/')
            if 'github.com' not in clean_url:
                return
            
            parts = clean_url.split('github.com/')[-1].split('/')
            if len(parts) < 2:
                return
            
            owner, repo, branch = parts[0], parts[1], 'main'
            if len(parts) > 3 and parts[2] == 'tree':
                branch = parts[3]
            
            deploy_log(f"Repository: {owner}/{repo}")
            deploy_log(f"Branch: {branch}")
            
            api_url = f"https://api.github.com/repos/{owner}/{repo}/zipball/{branch}"
            headers = {'Accept': 'application/vnd.github.v3+json'}
            
            if is_private and access_token:
                headers['Authorization'] = f'token {access_token}'
                deploy_log("Using private repository with token")
            else:
                deploy_log("Using public repository")
            
            response = requests.get(api_url, headers=headers, stream=True, timeout=60)
            
            if response.status_code == 200:
                deploy_log("Download successful!")
                temp_zip = os.path.join(server_dir, '_github_temp.zip')
                
                with open(temp_zip, 'wb') as f:
                    for chunk in response.iter_content(chunk_size=8192):
                        f.write(chunk)
                
                deploy_log("Extracting files...")
                try:
                    with zipfile.ZipFile(temp_zip, 'r') as zf:
                        for member in zf.namelist():
                            relative_path = '/'.join(member.split('/')[1:])
                            if not relative_path:
                                continue
                            target_path = os.path.join(server_dir, relative_path)
                            if member.endswith('/'):
                                os.makedirs(target_path, exist_ok=True)
                            else:
                                os.makedirs(os.path.dirname(target_path), exist_ok=True)
                                with zf.open(member) as source, open(target_path, 'wb') as target:
                                    shutil.copyfileobj(source, target)
                    deploy_log("✅ Extraction complete!")
                except Exception as e:
                    deploy_log(f"❌ Extraction error: {str(e)}")
                finally:
                    try:
                        os.remove(temp_zip)
                    except:
                        pass
            else:
                deploy_log(f"❌ Download failed: HTTP {response.status_code}")
                
        except Exception as e:
            try:
                with open(log_file, 'a', encoding='utf-8') as f:
                    f.write(f"[{datetime.now().strftime('%I:%M:%S %p')}] ❌ Error: {str(e)}\n")
            except:
                pass
    
    threading.Thread(target=deploy_thread, daemon=True).start()
    audit_log('GITHUB_DEPLOY', session['user'], f"Server: {server_id}, Repo: {repo_url}")
    
    return jsonify({'status': 'success', 'msg': 'Deployment started!'})

@app.route('/api/github/logs/<server_id>')
@login_required
def api_github_logs(server_id):
    log_file = os.path.join(get_server_dir(server_id), 'github_deploy.log')
    if os.path.exists(log_file):
        with open(log_file, 'r', encoding='utf-8') as f:
            logs = f.read()
    else:
        logs = "> Ready..."
    return jsonify({'logs': logs})

@app.route('/api/github/clear_logs/<server_id>', methods=['POST'])
@login_required
def api_github_clear_logs(server_id):
    log_file = os.path.join(get_server_dir(server_id), 'github_deploy.log')
    try:
        if os.path.exists(log_file):
            os.remove(log_file)
        return jsonify({'status': 'success'})
    except:
        return jsonify({'status': 'error'}), 500

# ============================================
# FILE API
# ============================================
@app.route('/api/files/<server_id>')
@login_required
@require_valid_server
def api_files(server_id):
    folder = request.args.get('folder', '')
    server_dir = get_server_dir(server_id)
    
    if folder:
        server_dir = os.path.join(server_dir, folder)
        if not os.path.abspath(server_dir).startswith(os.path.abspath(get_server_dir(server_id))):
            return jsonify({'files': []})
    
    if not os.path.exists(server_dir):
        return jsonify({'files': []})
    
    files = []
    try:
        for item in os.listdir(server_dir):
            item_path = os.path.join(server_dir, item)
            files.append({
                'name': item,
                'is_dir': os.path.isdir(item_path),
                'size': os.path.getsize(item_path) if os.path.isfile(item_path) else 0,
                'modified': datetime.fromtimestamp(os.path.getmtime(item_path)).strftime('%Y-%m-%d %H:%M')
            })
    except:
        pass
    
    return jsonify({'files': files})

@app.route('/api/file/<server_id>', methods=['GET'])
@login_required
@require_valid_server
def api_get_file(server_id):
    filename = request.args.get('filename', '')
    
    if '..' in filename or filename.startswith('/'):
        return jsonify({'error': 'Invalid filename'}), 400
    
    filepath = os.path.join(get_server_dir(server_id), filename)
    
    if os.path.exists(filepath) and os.path.isfile(filepath):
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
        return jsonify({'content': content})
    
    return jsonify({'error': 'Not found'}), 404

@app.route('/api/file/<server_id>', methods=['POST'])
@login_required
@require_valid_server
def api_save_file(server_id):
    data = request.get_json()
    filename = data.get('filename', '')
    
    if '..' in filename or filename.startswith('/'):
        return jsonify({'error': 'Invalid filename'}), 400
    
    filepath = os.path.join(get_server_dir(server_id), filename)
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(data.get('content', ''))
    
    audit_log('FILE_SAVE', session['user'], f"Server: {server_id}, File: {filename}")
    return jsonify({'success': True})

@app.route('/api/file/<server_id>', methods=['DELETE'])
@login_required
@require_valid_server
def api_delete_file(server_id):
    data = request.get_json()
    filename = data.get('filename', '')
    
    if '..' in filename or filename.startswith('/'):
        return jsonify({'error': 'Invalid filename'}), 400
    
    filepath = os.path.join(get_server_dir(server_id), filename)
    
    if os.path.exists(filepath):
        if os.path.isdir(filepath):
            shutil.rmtree(filepath)
        else:
            os.remove(filepath)
        audit_log('FILE_DELETE', session['user'], f"Server: {server_id}, File: {filename}")
        return jsonify({'success': True})
    
    return jsonify({'error': 'Not found'}), 404

@app.route('/api/upload/<server_id>', methods=['POST'])
@login_required
@require_valid_server
def api_upload(server_id):
    if 'file' not in request.files:
        return jsonify({'error': 'No file'}), 400
    
    folder = request.form.get('folder', '')
    server_dir = get_server_dir(server_id)
    
    if folder:
        if '..' in folder or folder.startswith('/'):
            return jsonify({'error': 'Invalid folder'}), 400
        server_dir = os.path.join(server_dir, folder)
        os.makedirs(server_dir, exist_ok=True)
    
    file = request.files['file']
    
    allowed_extensions = ['.py', '.txt', '.json', '.yml', '.yaml', '.md', '.html', '.css', '.js']
    filename = file.filename
    ext = os.path.splitext(filename)[1].lower()
    
    if ext not in allowed_extensions and ext != '':
        return jsonify({'error': 'File type not allowed!'}), 400
    
    file.save(os.path.join(server_dir, filename))
    audit_log('FILE_UPLOAD', session['user'], f"Server: {server_id}, File: {filename}")
    return jsonify({'success': True})

@app.route('/api/create_folder/<server_id>', methods=['POST'])
@login_required
@require_valid_server
def api_create_folder(server_id):
    data = request.get_json()
    foldername = data.get('foldername', '')
    
    if '..' in foldername or foldername.startswith('/'):
        return jsonify({'error': 'Invalid folder name'}), 400
    
    os.makedirs(os.path.join(get_server_dir(server_id), foldername), exist_ok=True)
    audit_log('FOLDER_CREATE', session['user'], f"Server: {server_id}, Folder: {foldername}")
    return jsonify({'success': True})

@app.route('/api/rename/<server_id>', methods=['POST'])
@login_required
@require_valid_server
def api_rename(server_id):
    data = request.get_json()
    old_name = data.get('old_name', '')
    new_name = data.get('new_name', '')
    
    if '..' in old_name or '..' in new_name or old_name.startswith('/') or new_name.startswith('/'):
        return jsonify({'error': 'Invalid name'}), 400
    
    server_dir = get_server_dir(server_id)
    old_path = os.path.join(server_dir, old_name)
    new_path = os.path.join(server_dir, new_name)
    
    if os.path.exists(old_path):
        os.rename(old_path, new_path)
        audit_log('FILE_RENAME', session['user'], f"Server: {server_id}, {old_name} -> {new_name}")
        return jsonify({'success': True})
    
    return jsonify({'error': 'Not found'}), 404

# ============================================
# NODE MANAGEMENT PAGE
# ============================================

@app.route('/admin/nodes')
@login_required
@admin_required
def admin_nodes_page():
    nodes_data = load_nodes()
    return render_template('admin_nodes.html', nodes_data=nodes_data)

@app.route('/admin/api/nodes/list')
@login_required
@admin_required
def admin_list_nodes():
    nodes_data = load_nodes()
    nodes_list = []
    
    for node_id, node in nodes_data['nodes'].items():
        status = node.get('status', 'unknown')
        if status == 'online':
            try:
                import requests
                node_url = f"http://{node['host']}:5000/api/node/health"
                headers = {'X-Node-Key': node.get('api_key', '')}
                response = requests.get(node_url, headers=headers, timeout=3)
                if response.status_code == 200:
                    health_data = response.json()
                    node['current_servers'] = health_data.get('server_count', 0)
                    node['cpu_usage'] = health_data.get('cpu_usage', 0)
                    node['memory_usage'] = health_data.get('memory_usage', 0)
                    node['disk_usage'] = health_data.get('disk_usage', 0)
                    status = 'online'
                else:
                    status = 'degraded'
            except:
                status = 'offline'
                node['status'] = 'offline'
        
        nodes_list.append({
            'id': node_id,
            'name': node.get('name', node_id),
            'host': node.get('host', ''),
            'port': node.get('port', 5000),
            'status': status,
            'current_servers': node.get('current_servers', 0),
            'max_servers': node.get('max_servers', 50),
            'last_heartbeat': node.get('last_heartbeat', 'Never'),
            'location': node.get('location', 'Unknown'),
            'port_start': node.get('port_start', 5001),
            'port_end': node.get('port_end', 5100),
            'cpu_usage': node.get('cpu_usage', 0),
            'memory_usage': node.get('memory_usage', 0),
            'disk_usage': node.get('disk_usage', 0),
            'uptime': node.get('uptime', 'Unknown'),
            'api_key': node.get('api_key', '')
        })
    
    mapping = nodes_data.get('server_node_mapping', {})
    
    return jsonify({
        'success': True,
        'nodes': nodes_list,
        'mapping': mapping,
        'total_nodes': len(nodes_list),
        'online_nodes': sum(1 for n in nodes_list if n['status'] == 'online')
    })

@app.route('/admin/api/nodes/add', methods=['POST'])
def admin_add_node():
    """Add a new worker node (auto-register with node key)"""
    data = request.get_json()
    
    if not data:
        return jsonify({'error': 'Invalid JSON data'}), 400
    
    # Check if it's a worker node auto-registration
    node_key = data.get('node_key', '')
    uses_tunnel = data.get('uses_tunnel', False)
    
    # If no node_key and not logged in as admin, deny
    if not node_key:
        if 'user' not in session or session.get('role') != 'admin':
            return jsonify({'error': 'Authentication required'}), 401
    
    host = data.get('host', '').strip()
    name = sanitize_input(data.get('name', ''))
    port = data.get('port', 5000)
    max_servers = int(data.get('max_servers', 50))
    location = sanitize_input(data.get('location', 'Unknown'))
    
    if not host:
        return jsonify({'error': 'Host is required!'}), 400
    
    nodes_data = load_nodes()
    
    # Check if node already exists
    for node_id, node in nodes_data['nodes'].items():
        if node.get('host') == host and node.get('port') == port:
            return jsonify({'error': 'Node already exists!'}), 400
    
    # Generate node ID
    node_id = f"node_{secrets.token_hex(4).lower()}"
    api_key = f"node_{node_id}_{secrets.token_urlsafe(24)}"
    
    # If node_key provided, use it as api_key
    if node_key:
        api_key = f"node_{node_id}_{secrets.token_urlsafe(24)}"
    
    nodes_data['nodes'][node_id] = {
        'id': node_id,
        'name': name or f"Node {node_id}",
        'host': host,
        'port': port,
        'api_key': api_key,
        'max_servers': max_servers,
        'current_servers': 0,
        'status': 'pending',
        'location': location,
        'port_start': 5001,
        'port_end': 5100,
        'last_heartbeat': str(datetime.now()),
        'created_at': str(datetime.now()),
        'cpu_usage': 0,
        'memory_usage': 0,
        'disk_usage': 0,
        'uptime': '0h',
        'auto_registered': bool(node_key)
    }
    
    save_nodes(nodes_data)
    audit_log('NODE_ADD', session.get('user', 'auto_register'), f"Node: {node_id}, Host: {host}")
    
    return jsonify({
        'success': True,
        'message': 'Node added successfully!',
        'node_id': node_id,
        'api_key': api_key
    })

@app.route('/admin/api/nodes/remove/<node_id>', methods=['POST'])
@login_required
@admin_required
def admin_remove_node(node_id):
    nodes_data = load_nodes()
    
    if node_id not in nodes_data['nodes']:
        return jsonify({'error': 'Node not found!'}), 404
    
    if nodes_data['nodes'][node_id].get('current_servers', 0) > 0:
        return jsonify({'error': 'Cannot remove node with active servers! First migrate or delete servers.'}), 400
    
    del nodes_data['nodes'][node_id]
    
    mapping = nodes_data.get('server_node_mapping', {})
    mapping = {k: v for k, v in mapping.items() if v != node_id}
    nodes_data['server_node_mapping'] = mapping
    
    save_nodes(nodes_data)
    audit_log('NODE_REMOVE', session['user'], f"Node: {node_id}")
    
    return jsonify({
        'success': True,
        'message': f'Node {node_id} removed successfully!'
    })


@app.route('/admin/api/nodes/check/<node_id>', methods=['POST'])
@login_required
@admin_required
def admin_check_node(node_id):
    """Check node health manually (Tunnel support)"""
    import requests
    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
    
    nodes_data = load_nodes()
    node = nodes_data['nodes'].get(node_id)
    
    if not node:
        return jsonify({'error': 'Node not found!'}), 404
    
    try:
        # Extract host without port (for Tunnel domains)
        host = node['host']
        # Remove port if present (e.g., node.yutacloud.site:5000 -> node.yutacloud.site)
        if ':' in host:
            host = host.split(':')[0]
        
        api_key = node.get('api_key', '')
        
        # Use HTTPS for Tunnel (no port needed)
        node_url = f"https://{host}/api/worker/health"
        
        print(f"[NODE_CHECK] Checking: {node_url}")
        print(f"[NODE_CHECK] API Key: {api_key[:20]}...")
        
        headers = {'X-Node-Key': api_key}
        
        start_time = time.time()
        response = requests.get(
            node_url, 
            headers=headers, 
            timeout=10, 
            verify=False
        )
        response_time = round((time.time() - start_time) * 1000, 2)
        
        print(f"[NODE_CHECK] Status: {response.status_code}")
        print(f"[NODE_CHECK] Response: {response.text[:200]}")
        
        if response.status_code == 200:
            health_data = response.json()
            
            node['status'] = 'online'
            node['last_heartbeat'] = str(datetime.now())
            node['current_servers'] = health_data.get('server_count', 0)
            node['cpu_usage'] = health_data.get('cpu_usage', 0)
            node['memory_usage'] = health_data.get('memory_usage', 0)
            node['disk_usage'] = health_data.get('disk_usage', 0)
            node['uptime'] = health_data.get('uptime', '0h')
            
            save_nodes(nodes_data)
            
            return jsonify({
                'success': True,
                'status': 'online',
                'response_time': response_time,
                'data': health_data,
                'message': 'Node is healthy!'
            })
        else:
            node['status'] = 'degraded'
            save_nodes(nodes_data)
            return jsonify({
                'success': False,
                'status': 'degraded',
                'response_time': response_time,
                'message': f'Node returned status {response.status_code}',
                'response': response.text[:200]
            })
            
    except requests.exceptions.ConnectionError as e:
        print(f"[NODE_CHECK] Connection error: {e}")
        node['status'] = 'offline'
        save_nodes(nodes_data)
        return jsonify({
            'success': False,
            'status': 'offline',
            'message': f'Connection failed: {str(e)}'
        })
    except requests.exceptions.Timeout:
        node['status'] = 'degraded'
        save_nodes(nodes_data)
        return jsonify({
            'success': False,
            'status': 'degraded',
            'message': 'Request timeout! Node is slow or unreachable.'
        })
    except Exception as e:
        print(f"[NODE_CHECK] Error: {e}")
        node['status'] = 'error'
        save_nodes(nodes_data)
        return jsonify({
            'success': False,
            'status': 'error',
            'message': f'Error: {str(e)}'
        })

@app.route('/admin/api/nodes/migrate', methods=['POST'])
@login_required
@admin_required
def admin_migrate_server():
    data = request.get_json()
    server_id = data.get('server_id')
    target_node = data.get('target_node')
    stop_server = data.get('stop_server', True)
    
    if not server_id or not target_node:
        return jsonify({'error': 'Server ID and target node required!'}), 400
    
    nodes_data = load_nodes()
    
    if target_node not in nodes_data['nodes']:
        return jsonify({'error': 'Target node not found!'}), 404
    
    if nodes_data['nodes'][target_node].get('current_servers', 0) >= nodes_data['nodes'][target_node].get('max_servers', 50):
        return jsonify({'error': 'Target node is full!'}), 400
    
    server, username = get_server_by_id(server_id)
    if not server:
        return jsonify({'error': 'Server not found!'}), 404
    
    current_node = nodes_data['server_node_mapping'].get(server_id)
    if not current_node:
        return jsonify({'error': 'Server not assigned to any node!'}), 404
    
    if current_node == target_node:
        return jsonify({'error': 'Server already on target node!'}), 400
    
    if stop_server and server.get('pid'):
        stop_bot_process(server['pid'])
        server['status'] = 'stopped'
        server['pid'] = None
        
        users = load_users()
        for uname, udata in users.items():
            if uname == 'admin': continue
            for s in udata.get('servers', []):
                if s.get('server_id') == server_id:
                    s['status'] = 'stopped'
                    s['pid'] = None
                    save_users(users)
                    break
    
    nodes_data['server_node_mapping'][server_id] = target_node
    nodes_data['nodes'][current_node]['current_servers'] -= 1
    nodes_data['nodes'][target_node]['current_servers'] += 1
    
    users = load_users()
    for uname, udata in users.items():
        if uname == 'admin': continue
        for s in udata.get('servers', []):
            if s.get('server_id') == server_id:
                s['node'] = target_node
                save_users(users)
                break
    
    save_nodes(nodes_data)
    audit_log('SERVER_MIGRATE', session['user'], f"Server: {server_id}, From: {current_node}, To: {target_node}")
    
    return jsonify({
        'success': True,
        'message': f'Server {server_id} migrated from {current_node} to {target_node}!',
        'server_id': server_id,
        'current_node': current_node,
        'target_node': target_node
    })

@app.route('/admin/api/nodes/servers/<node_id>')
@login_required
@admin_required
def admin_get_node_servers(node_id):
    nodes_data = load_nodes()
    
    if node_id not in nodes_data['nodes']:
        return jsonify({'error': 'Node not found!'}), 404
    
    mapping = nodes_data.get('server_node_mapping', {})
    server_ids = [sid for sid, nid in mapping.items() if nid == node_id]
    
    servers = []
    users = load_users()
    
    for sid in server_ids:
        server, username = get_server_by_id(sid)
        if server:
            servers.append({
                'server_id': sid,
                'username': username,
                'ram': server.get('ram', 'N/A'),
                'disk': server.get('disk', 'N/A'),
                'cpu_limit': server.get('cpu_limit', 80),
                'status': server.get('status', 'stopped'),
                'port': server.get('port', get_server_port(sid)),
                'expiry': server.get('expiry', ''),
                'created': server.get('created', '')
            })
    
    return jsonify({
        'success': True,
        'node_id': node_id,
        'server_count': len(servers),
        'servers': servers
    })

@app.route('/admin/api/nodes/stats')
@login_required
@admin_required
def admin_get_nodes_stats():
    nodes_data = load_nodes()
    mapping = nodes_data.get('server_node_mapping', {})
    
    stats = {
        'total_nodes': len(nodes_data['nodes']),
        'online_nodes': 0,
        'offline_nodes': 0,
        'total_servers': len(mapping),
        'max_capacity': 0,
        'current_load': 0,
        'nodes': []
    }
    
    for node_id, node in nodes_data['nodes'].items():
        status = node.get('status', 'unknown')
        current = node.get('current_servers', 0)
        max_servers = node.get('max_servers', 50)
        
        if status == 'online':
            stats['online_nodes'] += 1
        else:
            stats['offline_nodes'] += 1
        
        stats['max_capacity'] += max_servers
        stats['current_load'] += current
        
        stats['nodes'].append({
            'id': node_id,
            'name': node.get('name', node_id),
            'status': status,
            'current_servers': current,
            'max_servers': max_servers,
            'load_percent': round((current / max_servers) * 100, 1) if max_servers > 0 else 0,
            'cpu_usage': node.get('cpu_usage', 0),
            'memory_usage': node.get('memory_usage', 0),
            'disk_usage': node.get('disk_usage', 0)
        })
    
    if stats['max_capacity'] > 0:
        stats['overall_load'] = round((stats['current_load'] / stats['max_capacity']) * 100, 1)
    else:
        stats['overall_load'] = 0
    
    return jsonify({'success': True, 'stats': stats})

@app.route('/api/unzip/<server_id>', methods=['POST'])
@login_required
@require_valid_server
def api_unzip(server_id):
    data = request.get_json()
    filename = data.get('filename', '')
    
    if '..' in filename or filename.startswith('/'):
        return jsonify({'error': 'Invalid filename'}), 400
    
    zip_path = os.path.join(get_server_dir(server_id), filename)
    
    if os.path.exists(zip_path) and zip_path.endswith('.zip'):
        try:
            with zipfile.ZipFile(zip_path, 'r') as zf:
                zf.extractall(os.path.dirname(zip_path))
            audit_log('FILE_UNZIP', session['user'], f"Server: {server_id}, File: {filename}")
            return jsonify({'status': 'success', 'msg': 'Extracted!'})
        except Exception as e:
            return jsonify({'status': 'error', 'msg': str(e)})
    
    return jsonify({'status': 'error', 'msg': 'Invalid zip'}), 400

@app.route('/api/get_startup/<server_id>')
@login_required
@require_valid_server
def api_get_startup(server_id):
    server, _ = get_server_by_id(server_id)
    if server:
        return jsonify({
            'main_file': server.get('main_file', 'main.py'),
            'requirements_file': server.get('requirements_file', 'requirements.txt')
        })
    return jsonify({'main_file': 'main.py', 'requirements_file': 'requirements.txt'})

@app.route('/api/set_startup/<server_id>', methods=['POST'])
@login_required
@require_valid_server
def api_set_startup(server_id):
    data = request.get_json()
    main_file = data.get('main_file', 'main.py')
    requirements_file = data.get('requirements_file', '')
    
    if '..' in main_file or '..' in requirements_file:
        return jsonify({'error': 'Invalid filename'}), 400
    
    users = load_users()
    for uname, udata in users.items():
        if uname == 'admin': continue
        servers = udata.get('servers', [])
        if not isinstance(servers, list): continue
        for s in servers:
            if isinstance(s, dict) and s.get('server_id') == server_id:
                s['main_file'] = main_file
                s['requirements_file'] = requirements_file
                save_users(users)
                audit_log('STARTUP_UPDATE', session['user'], f"Server: {server_id}")
                return jsonify({'success': True})
    
    return jsonify({'error': 'Not found'}), 404

# ============================================
# SUBDOMAIN ROUTER
# ============================================
@app.before_request
def subdomain_router():
    host = request.host
    base_domain = 'yutacloud.site'
    
    if host == base_domain or host == f"www.{base_domain}":
        return None
    
    if not host.endswith('.' + base_domain):
        return None
    
    server_id = host.replace('.' + base_domain, '').upper()
    
    if server_id in ['login', 'admin', 'api', 'static', 'signin', 'signup', 'pricing', 'checkout']:
        return None
    
    import requests as req_lib
    
    server, username = get_server_by_id(server_id)
    
    if not server:
        return render_template('subdomain_error.html',
            error_type='deleted',
            server_id=server_id,
            server_link=server_id,
            base_domain=base_domain), 404
    
    expiry = server.get('expiry', '')
    if expiry:
        try:
            exp_date = datetime.strptime(expiry, '%Y-%m-%d %H:%M:%S.%f')
            if datetime.now() > exp_date:
                return render_template('subdomain_error.html',
                    error_type='expired',
                    server_id=server_id,
                    server_link=server_id,
                    expiry_date=expiry[:10],
                    base_domain=base_domain), 410
        except:
            pass
    
    if server.get('status') != 'running':
        return render_template('subdomain_error.html',
            error_type='offline',
            server_id=server_id,
            server_link=server_id,
            username=username,
            base_domain=base_domain), 503
    
    internal_port = server.get('port') or get_server_port(server_id)
    if not internal_port:
        return render_template('subdomain_error.html',
            error_type='no_port',
            server_id=server_id,
            server_link=server_id,
            base_domain=base_domain), 500
    
    path = request.full_path
    target_url = f"http://127.0.0.1:{internal_port}{path}"
    
    headers = {key: value for key, value in request.headers if key.lower() != 'host'}
    headers['Host'] = host
    headers['X-Forwarded-For'] = request.remote_addr
    headers['X-Forwarded-Proto'] = 'https'
    headers['X-Server-Id'] = server_id
    
    try:
        if request.method == 'GET':
            resp = req_lib.get(target_url, headers=headers, params=request.args,
                             timeout=30, allow_redirects=True)
        elif request.method == 'POST':
            resp = req_lib.post(target_url, headers=headers, data=request.get_data(),
                              params=request.args, timeout=30)
        elif request.method == 'PUT':
            resp = req_lib.put(target_url, headers=headers, data=request.get_data(),
                             params=request.args, timeout=30)
        elif request.method == 'DELETE':
            resp = req_lib.delete(target_url, headers=headers, params=request.args,
                                timeout=30)
        else:
            resp = req_lib.request(method=request.method, url=target_url,
                                 headers=headers, data=request.get_data(),
                                 params=request.args, timeout=30)
        
        from flask import Response
        excluded = ['content-encoding', 'transfer-encoding', 'connection']
        response_headers = [(name, value) for name, value in resp.headers.items()
                          if name.lower() not in excluded]
        
        return Response(resp.content, resp.status_code, response_headers)
        
    except req_lib.exceptions.ConnectionError:
        return render_template('subdomain_error.html',
            error_type='offline',
            server_id=server_id,
            server_link=server_id,
            username=username,
            base_domain=base_domain), 502
    except Exception as e:
        return render_template('subdomain_error.html',
            error_type='error',
            server_id=server_id,
            server_link=server_id,
            error_message=str(e),
            base_domain=base_domain), 500

# ============================================
# START THREADS
# ============================================
def start_background_threads():
    cleanup_thread = threading.Thread(target=auto_cleanup_expired_ports, daemon=True)
    cleanup_thread.start()
    logger.info("[THREAD] Auto port cleanup started")
    
    delete_thread = threading.Thread(target=auto_delete_expired_servers, daemon=True)
    delete_thread.start()
    logger.info("[THREAD] Auto server deletion started (3 days grace period)")

# ============================================
# MAIN
# ============================================
if __name__ == '__main__':
    settings = load_yuta_settings()
    if settings.get('bohudur_api_key'):
        bohudur.set_api_key(settings['bohudur_api_key'])
    
    load_port_allocations()
    
    start_background_threads()
    
    print("\n" + "=" * 60)
    print("🚀 YUTA CLOUD HOSTING v2.0 - SECURE EDITION")
    print("=" * 60)
    print("📍 Landing: http://localhost:5000")
    print("📍 Sign In: http://localhost:5000/signin")
    print("📍 Sign Up: http://localhost:5000/signup")
    print("📍 Pricing: http://localhost:5000/pricing")
    print("📍 Admin: http://localhost:5000/login")
    print("📍 Admin Packages: http://localhost:5000/admin/packages")
    print("📍 Admin Resources: http://localhost:5000/admin/resources")
    print("📍 Admin Ports: http://localhost:5000/admin/ports")
    print("📍 Admin Maintenance: http://localhost:5000/admin/maintenance")
    print("📍 Admin Nodes: http://localhost:5000/admin/nodes")
    print("🔌 Port Range: 5001-6000")
    print("👤 admin / yuta_005")
    print("🔒 Auto-delete: 3 days after expiry")
    print("=" * 60 + "\n")
    
    app.run(debug=False, host='0.0.0.0', port=3000)